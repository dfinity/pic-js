---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:254](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L254)

Flag for configuration options in `IcpConfig`.

## Enumeration Members

### Disabled

> **Disabled**: `"Disabled"`

Defined in: [packages/pic/src/pocket-ic-types.ts:255](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L255)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [packages/pic/src/pocket-ic-types.ts:256](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L256)

---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:967](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L967)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:971](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L971)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:981](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L981)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:976](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L976)

A POST request.

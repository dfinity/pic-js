---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:195](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L195)

Options for a verified application subnet's state.

---
title: SystemSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:173](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L173)

Options for a system subnet's state.

---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:178](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L178)

Options for creating an application subnet.

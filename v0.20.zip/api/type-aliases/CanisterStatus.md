---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

> **CanisterStatus** = \{ `running`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `stopped`: `null`; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:767](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L767)

The status of a canister.

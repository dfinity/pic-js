---
title: LogVisibility
editUrl: false
next: true
prev: true
---

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:475](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L475)

Log visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

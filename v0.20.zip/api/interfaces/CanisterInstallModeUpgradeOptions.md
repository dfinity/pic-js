---
title: CanisterInstallModeUpgradeOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/management-canister.ts:144](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/management-canister.ts#L144)

## Properties

### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/pic/src/management-canister.ts:145](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/management-canister.ts#L145)

***

### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[\] \| \[\{ `keep?`: `null`; `replace?`: `null`; \}\]

Defined in: [packages/pic/src/management-canister.ts:146](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/management-canister.ts#L146)

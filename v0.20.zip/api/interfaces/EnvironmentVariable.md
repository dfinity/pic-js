---
title: EnvironmentVariable
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:464](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L464)

Environment variable for canister settings.

## Properties

### name

> **name**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:465](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L465)

***

### value

> **value**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:466](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L466)

---
title: IcpConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:262](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L262)

Configures IC protocol properties.

## Properties

### betaFeatures?

> `optional` **betaFeatures**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:266](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L266)

Beta features (disabled on the ICP mainnet).

***

### canisterBacktrace?

> `optional` **canisterBacktrace**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:270](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L270)

Canister backtraces (enabled on the ICP mainnet).

***

### canisterExecutionRateLimiting?

> `optional` **canisterExecutionRateLimiting**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:279](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L279)

Rate-limiting of canister execution (enabled on the ICP mainnet).
Canister execution refers to instructions and memory writes here.

***

### functionNameLengthLimits?

> `optional` **functionNameLengthLimits**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:274](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L274)

Limits on function name length in canister WASM (enabled on the ICP mainnet).

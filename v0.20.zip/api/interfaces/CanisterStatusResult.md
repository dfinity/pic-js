---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:791](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L791)

The result of querying the status of a canister.
Matches the IC management canister `canister_status` response.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:825](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L825)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:835](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L835)

The amount of cycles burned per day when idle.

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:820](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L820)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:815](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L815)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:840](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L840)

Query call statistics for the canister.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:830](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L830)

The reserved cycles of the canister.

***

### settings

> **settings**: `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:800](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L800)

The definite settings of the canister.

#### computeAllocation

> **computeAllocation**: `bigint`

#### controllers

> **controllers**: `Principal`[]

#### environmentVariables

> **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

#### freezingThreshold

> **freezingThreshold**: `bigint`

#### logVisibility

> **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

#### memoryAllocation

> **memoryAllocation**: `bigint`

#### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

#### wasmMemoryLimit

> **wasmMemoryLimit**: `bigint`

#### wasmMemoryThreshold

> **wasmMemoryThreshold**: `bigint`

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:795](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L795)

The current status of the canister.

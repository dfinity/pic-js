---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:200](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L200)

Options for creating a new subnet an empty state.

## Properties

### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [packages/pic/src/pocket-ic-types.ts:204](https://github.com/dfinity/pic-js/blob/b1d209276a43f434267e43fc529d9b3aff4879ea/packages/pic/src/pocket-ic-types.ts#L204)

The type of subnet state to initialize the subnet with.

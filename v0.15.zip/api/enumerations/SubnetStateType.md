---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:230](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L230)

The type of state to initialize a subnet with.


### FromPath

> **FromPath**: `"fromPath"`

Defined in: [pocket-ic-types.ts:240](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L240)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [pocket-ic-types.ts:234](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L234)

Create a new subnet with an empty state.

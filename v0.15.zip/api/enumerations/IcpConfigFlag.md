---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:246](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L246)

Flag for configuration options in `IcpConfig`.


### Disabled

> **Disabled**: `"Disabled"`

Defined in: [pocket-ic-types.ts:247](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L247)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [pocket-ic-types.ts:248](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L248)

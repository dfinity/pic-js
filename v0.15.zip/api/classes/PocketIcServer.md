---
title: PocketIcServer
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-server.ts:47](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-server.ts#L47)

This class represents the main PocketIC server.
It is responsible for maintaining the lifecycle of the server process.
See [PocketIc](PocketIc.md) for details on the client to use with this server.


```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const fixture = await pic.setupCanister<_SERVICE>({ idlFactory, wasmPath });
const { actor } = fixture;

// perform tests...

await pic.tearDown();
await picServer.stop();
```

## Methods

### getUrl()

> **getUrl**(): `string`

Defined in: [pocket-ic-server.ts:114](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-server.ts#L114)

Get the URL of the server.

#### Returns

`string`

The URL of the server.

***

### stop()

> **stop**(): `Promise`\<`void`\>

Defined in: [pocket-ic-server.ts:123](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-server.ts#L123)

Stop the server.

#### Returns

`Promise`\<`void`\>

A promise that resolves when the server has stopped.

***

### start()

> `static` **start**(`options`): `Promise`\<`PocketIcServer`\>

Defined in: [pocket-ic-server.ts:63](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-server.ts#L63)

Start a new PocketIC server.

#### Parameters

##### options

[`StartServerOptions`](../interfaces/StartServerOptions.md) = `{}`

Options for starting the server.

#### Returns

`Promise`\<`PocketIcServer`\>

An instance of the PocketIC server.

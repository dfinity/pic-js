---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:406](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L406)

Options for setting up a canister.


- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:423](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L423)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:467](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L467)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:462](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L462)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:496](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L496)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:477](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L477)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [pocket-ic-types.ts:410](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L410)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:472](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L472)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:482](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L482)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:429](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L429)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:513](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L513)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:507](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L507)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:417](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L417)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

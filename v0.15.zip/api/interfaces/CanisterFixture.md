---
title: CanisterFixture
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:439](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L439)

A canister testing fixture for PocketIC that provides essential testing primitives
such as an [Actor](Actor.md) and CanisterId.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

## Properties

### actor

> **actor**: [`Actor`](Actor.md)\<`T`\>

Defined in: [pocket-ic-types.ts:443](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L443)

The [Actor](Actor.md) instance.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:448](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L448)

The Principal of the canister.

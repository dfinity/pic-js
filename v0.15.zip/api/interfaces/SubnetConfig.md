---
title: SubnetConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:82](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L82)

Common options for creating a subnet.


### T

`T` *extends* [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md) = [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md)

## Properties

### enableBenchmarkingInstructionLimits?

> `optional` **enableBenchmarkingInstructionLimits**: `boolean`

Defined in: [pocket-ic-types.ts:97](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L97)

Whether to enable benchmarking instruction limits.
Defaults to `false`.

***

### enableDeterministicTimeSlicing?

> `optional` **enableDeterministicTimeSlicing**: `boolean`

Defined in: [pocket-ic-types.ts:91](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L91)

Whether to enable deterministic time slicing.
Defaults to `true`.

***

### state

> **state**: `T`

Defined in: [pocket-ic-types.ts:102](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L102)

The state configuration for the subnet.

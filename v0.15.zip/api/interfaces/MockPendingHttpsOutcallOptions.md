---
title: MockPendingHttpsOutcallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:838](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L838)

Options for mocking a response to a pending HTTPS outcall.


### additionalResponses?

> `optional` **additionalResponses**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)[]

Defined in: [pocket-ic-types.ts:860](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L860)

Additional responses to mock for the pending HTTPS outcall.

If non-empty, the total number of responses (one plus the number of additional responses)
must be equal to the size of the subnet on which the canister making the HTTP outcall is deployed.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:847](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L847)

The HTTPS Outcall request Id to mock a response for.

***

### response

> **response**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)

Defined in: [pocket-ic-types.ts:852](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L852)

The response to mock for the pending HTTPS outcall.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:842](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L842)

The subnet ID to that the HTTPS Outcall is being sent from.

---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:130](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L130)

Options for creating an II subnet.

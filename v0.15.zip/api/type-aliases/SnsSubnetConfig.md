---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:120](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L120)

Options for creating an SNS subnet.

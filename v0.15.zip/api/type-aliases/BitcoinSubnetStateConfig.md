---
title: BitcoinSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:155](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L155)

Options for a Bitcoin subnet's state.

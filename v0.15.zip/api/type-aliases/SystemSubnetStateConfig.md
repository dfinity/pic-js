---
title: SystemSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:165](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L165)

Options for a system subnet's state.

---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-deferred-actor.ts#L15)


### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

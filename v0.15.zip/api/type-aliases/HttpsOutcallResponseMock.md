---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [pocket-ic-types.ts:866](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L866)

An HTTPS Outcall response mock.

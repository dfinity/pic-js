---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.


### T

`T` = `object`

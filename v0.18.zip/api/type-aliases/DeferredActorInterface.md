---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-deferred-actor.ts#L15)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

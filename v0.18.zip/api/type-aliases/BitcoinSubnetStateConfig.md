---
title: BitcoinSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:163](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L163)

Options for a Bitcoin subnet's state.

---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:178](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L178)

Options for creating an application subnet.

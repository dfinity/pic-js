---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:200](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L200)

Options for creating a new subnet an empty state.

## Properties

### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [pocket-ic-types.ts:204](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L204)

The type of subnet state to initialize the subnet with.

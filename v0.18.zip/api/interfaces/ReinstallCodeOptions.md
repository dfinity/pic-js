---
title: ReinstallCodeOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:620](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L620)

Options for reinstalling a WASM module to a given canister.
This will reset both the canister's heap and its stable memory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:636](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L636)

Candid encoded argument to pass to the canister's init function.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:624](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L624)

The Principal of the canister to reinstall code to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:642](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L642)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:631](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L631)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

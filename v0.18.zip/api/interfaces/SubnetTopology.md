---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:342](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L342)

The topology of a subnet.

## Properties

### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [pocket-ic-types.ts:361](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L361)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [pocket-ic-types.ts:346](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L346)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [pocket-ic-types.ts:356](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L356)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [pocket-ic-types.ts:351](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L351)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

---
title: UpdateCallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:748](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L748)

Options for making an update call to a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:769](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L769)

A Candid encoded argument to pass to the canister's method.
Defaults to an empty Uint8Array.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:758](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L758)

The Principal of the canister to update.

***

### method

> **method**: `string`

Defined in: [pocket-ic-types.ts:763](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L763)

The method to call on the canister.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:753](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L753)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:774](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L774)

The ID of the subnet that the canister resides on.

---
title: UpdateCanisterSettingsOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:688](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L688)

Options for updating the settings of a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extends

- `Partial`\<[`CanisterSettings`](CanisterSettings.md)\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:693](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L693)

The Principal of the canister to update the settings for.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:475](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L475)

The compute allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`computeAllocation`](CanisterSettings.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:470](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L470)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`controllers`](CanisterSettings.md#controllers)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:485](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L485)

The freezing threshold of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`freezingThreshold`](CanisterSettings.md#freezingthreshold)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:480](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L480)

The memory allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`memoryAllocation`](CanisterSettings.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:490](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L490)

The reserved cycles limit of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`reservedCyclesLimit`](CanisterSettings.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:699](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L699)

The Principal to send the request as.
Defaults to the anonymous principal.

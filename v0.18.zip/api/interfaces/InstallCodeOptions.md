---
title: InstallCodeOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:582](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L582)

Options for installing a WASM module to a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:599](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L599)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty Uint8Array.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:586](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L586)

The Principal of the canister to install the code to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:605](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L605)

The principal to install the code as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:610](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L610)

The ID of the subnet that the canister resides on.

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:593](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L593)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

---
title: IcpConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:262](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L262)

Configures IC protocol properties.

## Properties

### betaFeatures?

> `optional` **betaFeatures**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:266](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L266)

Beta features (disabled on the ICP mainnet).

***

### canisterBacktrace?

> `optional` **canisterBacktrace**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:270](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L270)

Canister backtraces (enabled on the ICP mainnet).

***

### canisterExecutionRateLimiting?

> `optional` **canisterExecutionRateLimiting**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:279](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L279)

Rate-limiting of canister execution (enabled on the ICP mainnet).
Canister execution refers to instructions and memory writes here.

***

### functionNameLengthLimits?

> `optional` **functionNameLengthLimits**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:274](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L274)

Limits on function name length in canister WASM (enabled on the ICP mainnet).

---
title: CanisterFixture
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:447](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L447)

A canister testing fixture for PocketIC that provides essential testing primitives
such as an [Actor](Actor.md) and CanisterId.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

## Properties

### actor

> **actor**: [`Actor`](Actor.md)\<`T`\>

Defined in: [pocket-ic-types.ts:451](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L451)

The [Actor](Actor.md) instance.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:456](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L456)

The Principal of the canister.

---
title: CreateInstanceOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:14](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L14)

Options for creating a PocketIc instance.

## Properties

### application?

> `optional` **application**: [`ApplicationSubnetConfig`](../type-aliases/ApplicationSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:57](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L57)

Configuration options for creating application subnets.
An application subnet will be created for each configuration object provided.
If no config objects are provided, no application subnets are setup.

***

### bitcoin?

> `optional` **bitcoin**: [`BitcoinSubnetConfig`](../type-aliases/BitcoinSubnetConfig.md)

Defined in: [pocket-ic-types.ts:43](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L43)

Configuration options for creating a Bitcoin subnet.
If no config is provided, the Bitcoin subnet is not setup.

***

### fiduciary?

> `optional` **fiduciary**: [`FiduciarySubnetConfig`](../type-aliases/FiduciarySubnetConfig.md)

Defined in: [pocket-ic-types.ts:37](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L37)

Configuration options for creating a Fiduciary subnet.
If no config is provided, the Fiduciary subnet is not setup.

***

### icpConfig?

> `optional` **icpConfig**: [`IcpConfig`](IcpConfig.md)

Defined in: [pocket-ic-types.ts:79](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L79)

Determines what non-mainnet features should be
enabled for the PocketIC instance.

***

### icpFeatures?

> `optional` **icpFeatures**: [`IcpFeatures`](IcpFeatures.md)

Defined in: [pocket-ic-types.ts:84](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L84)

Determines what ICP features should be enabled for the PocketIC instance.

***

### ii?

> `optional` **ii**: [`IiSubnetConfig`](../type-aliases/IiSubnetConfig.md)

Defined in: [pocket-ic-types.ts:31](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L31)

Configuration options for creating an II subnet.
If no config is provided, the II subnet is not setup.

***

### ingressMaxRetries?

> `optional` **ingressMaxRetries**: `number`

Defined in: [pocket-ic-types.ts:74](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L74)

How many IngressStatusRounds all IC update calls should wait, till we get a timeout.

***

### nns?

> `optional` **nns**: [`NnsSubnetConfig`](../type-aliases/NnsSubnetConfig.md)

Defined in: [pocket-ic-types.ts:19](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L19)

Configuration options for creating an NNS subnet.
If no config is provided, the NNS subnet is not setup.

***

### processingTimeoutMs?

> `optional` **processingTimeoutMs**: `number`

Defined in: [pocket-ic-types.ts:69](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L69)

How long the PocketIC client should wait for a response from the server.

***

### sns?

> `optional` **sns**: [`SnsSubnetConfig`](../type-aliases/SnsSubnetConfig.md)

Defined in: [pocket-ic-types.ts:25](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L25)

Configuration options for creating an SNS subnet.
If no config is provided, the SNS subnet is not setup.

***

### system?

> `optional` **system**: [`SystemSubnetConfig`](../type-aliases/SystemSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:50](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L50)

Configuration options for creating system subnets.
A system subnet will be created for each configuration object provided.
If no config objects are provided, no system subnets are setup.

***

### verifiedApplication?

> `optional` **verifiedApplication**: [`VerifiedApplicationSubnetConfig`](../type-aliases/VerifiedApplicationSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:64](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L64)

Configuration options for creating verified application subnets.
A verified application subnet will be created for each configuration object provided.
If no config objects are provided, no verified application subnets are setup.

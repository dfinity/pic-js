---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:238](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L238)

The type of state to initialize a subnet with.

## Enumeration Members

### FromPath

> **FromPath**: `"fromPath"`

Defined in: [pocket-ic-types.ts:248](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L248)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [pocket-ic-types.ts:242](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L242)

Create a new subnet with an empty state.

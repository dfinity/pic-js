---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:254](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L254)

Flag for configuration options in `IcpConfig`.

## Enumeration Members

### Disabled

> **Disabled**: `"Disabled"`

Defined in: [pocket-ic-types.ts:255](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L255)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [pocket-ic-types.ts:256](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L256)

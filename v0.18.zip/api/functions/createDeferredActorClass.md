---
title: createDeferredActorClass
editUrl: false
next: true
prev: true
---

> **createDeferredActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic-deferred-actor.ts:80](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-deferred-actor.ts#L80)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

---
title: createIdentity
editUrl: false
next: true
prev: true
---

> **createIdentity**(`seedPhrase`): `Identity`

Defined in: [identity.ts:43](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/identity.ts#L43)

Create an Identity from a seed phrase.
The seed phrase can be any arbitrary string.

The Identity is generated deterministically from the seed phrase,
so subsequent calls to this function with the same seed phrase will
produce the same Identity.

This is useful for tests where a persistent Identity is necessary
but it's easier to store the seed phrase than the Identity itself.

## Parameters

### seedPhrase

`string`

The seed phrase to create the identity from. Can be any arbitrary string.

## Returns

`Identity`

An identity created from the seed phrase.

## See

[Identity](https://js.icp.build/core/latest/libs/agent/api/interfaces/identity/)

## Example

```ts
import { PocketIc, PocketIcServer, createIdentity } from '@dfinity/pic';
import { AnonymousIdentity } from '@icp-sdk/core/agent';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

const bob = createIdentity('SuperSecretSeedPhraseForBob');
actor.setIdentity(bob);

await pic.tearDown();
await picServer.stop();
```

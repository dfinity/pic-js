---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:300](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L300)

The type of a subnet.


### Application

> **Application**: `"Application"`

Defined in: [pocket-ic-types.ts:304](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L304)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [pocket-ic-types.ts:309](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L309)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [pocket-ic-types.ts:314](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L314)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [pocket-ic-types.ts:319](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L319)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [pocket-ic-types.ts:324](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L324)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [pocket-ic-types.ts:329](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L329)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [pocket-ic-types.ts:334](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L334)

The subnet is a system subnet.

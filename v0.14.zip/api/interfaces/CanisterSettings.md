---
title: CanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:395](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L395)

Canister settings.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extended by

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:405](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L405)

The compute allocation of the canister.

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:400](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L400)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:415](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L415)

The freezing threshold of the canister.

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:410](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L410)

The memory allocation of the canister.

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:420](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L420)

The reserved cycles limit of the canister.

---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:272](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L272)

The topology of a subnet.


### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [pocket-ic-types.ts:291](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L291)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [pocket-ic-types.ts:276](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L276)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [pocket-ic-types.ts:286](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L286)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [pocket-ic-types.ts:281](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L281)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

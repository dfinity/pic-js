---
title: CanisterFixture
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:377](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L377)

A canister testing fixture for PocketIC that provides essential testing primitives
such as an [Actor](Actor.md) and CanisterId.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

## Properties

### actor

> **actor**: [`Actor`](Actor.md)\<`T`\>

Defined in: [pocket-ic-types.ts:381](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L381)

The [Actor](Actor.md) instance.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:386](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L386)

The Principal of the canister.

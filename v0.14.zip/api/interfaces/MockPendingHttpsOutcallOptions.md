---
title: MockPendingHttpsOutcallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:776](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L776)

Options for mocking a response to a pending HTTPS outcall.


### additionalResponses?

> `optional` **additionalResponses**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)[]

Defined in: [pocket-ic-types.ts:798](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L798)

Additional responses to mock for the pending HTTPS outcall.

If non-empty, the total number of responses (one plus the number of additional responses)
must be equal to the size of the subnet on which the canister making the HTTP outcall is deployed.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:785](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L785)

The HTTPS Outcall request Id to mock a response for.

***

### response

> **response**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)

Defined in: [pocket-ic-types.ts:790](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L790)

The response to mock for the pending HTTPS outcall.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:780](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L780)

The subnet ID to that the HTTPS Outcall is being sent from.

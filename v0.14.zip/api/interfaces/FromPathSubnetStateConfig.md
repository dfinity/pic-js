---
title: FromPathSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:197](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L197)

Options for creating a subnet from an existing state on the filesystem.


### path

> **path**: `string`

Defined in: [pocket-ic-types.ts:219](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L219)

The path to the subnet state.

This directory should have the following structure:
```text
  |-- backups/
  |-- checkpoints/
  |-- diverged_checkpoints/
  |-- diverged_state_markers/
  |-- fs_tmp/
  |-- page_deltas/
  |-- tip/
  |-- tmp/
  |-- states_metadata.pbuf
```

***

### type

> **type**: [`FromPath`](../enumerations/SubnetStateType.md#frompath)

Defined in: [pocket-ic-types.ts:201](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L201)

The type of subnet state to initialize the subnet with.

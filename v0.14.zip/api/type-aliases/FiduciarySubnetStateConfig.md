---
title: FiduciarySubnetStateConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:140](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L140)

Options for a Fiduciary subnet's state.

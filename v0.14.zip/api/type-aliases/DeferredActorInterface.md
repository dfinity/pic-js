---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-deferred-actor.ts#L15)


### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

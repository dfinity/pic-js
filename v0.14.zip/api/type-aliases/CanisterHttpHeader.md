---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [pocket-ic-types.ts:771](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L771)

An HTTP header for an HTTPS outcall.

---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.


### T

`T` = `object`

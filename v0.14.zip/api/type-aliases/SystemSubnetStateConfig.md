---
title: SystemSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:160](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L160)

Options for a system subnet's state.

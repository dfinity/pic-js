---
title: NnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](../interfaces/FromPathSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:108](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L108)

Options for an NNS subnet's state.

---
title: VerifiedApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`VerifiedApplicationSubnetStateConfig`](VerifiedApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:176](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L176)

Options for creating a verified application subnet.

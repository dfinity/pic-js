---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:115](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L115)

Options for creating an SNS subnet.

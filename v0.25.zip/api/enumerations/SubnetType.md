---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:576](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L576)

The type of a subnet.

## Enumeration Members

### Application

> **Application**: `"Application"`

Defined in: [packages/pic/src/pocket-ic-types.ts:580](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L580)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [packages/pic/src/pocket-ic-types.ts:585](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L585)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [packages/pic/src/pocket-ic-types.ts:590](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L590)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [packages/pic/src/pocket-ic-types.ts:600](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L600)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [packages/pic/src/pocket-ic-types.ts:605](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L605)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [packages/pic/src/pocket-ic-types.ts:610](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L610)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [packages/pic/src/pocket-ic-types.ts:615](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L615)

The subnet is a system subnet.

***

### TestThresholdKeys

> **TestThresholdKeys**: `"TestThresholdKeys"`

Defined in: [packages/pic/src/pocket-ic-types.ts:595](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L595)

The subnet is a test threshold keys subnet.

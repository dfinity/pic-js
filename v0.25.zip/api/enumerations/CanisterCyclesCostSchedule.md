---
title: CanisterCyclesCostSchedule
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:265](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L265)

The canister cycles cost schedule for a subnet.
See the `SubnetSpec.cost_schedule` field in the PocketIC server.

## Enumeration Members

### Free

> **Free**: `"Free"`

Defined in: [packages/pic/src/pocket-ic-types.ts:274](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L274)

Canisters are not charged cycles. Only supported on application subnets.

***

### Normal

> **Normal**: `"Normal"`

Defined in: [packages/pic/src/pocket-ic-types.ts:269](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L269)

Canisters are charged cycles as on the ICP mainnet.

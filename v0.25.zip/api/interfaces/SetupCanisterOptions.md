---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:654](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L654)

Options for setting up a canister.

## Extends

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:671](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L671)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty Uint8Array.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:765](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L765)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:760](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L760)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:838](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L838)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### environmentVariables?

> `optional` **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:824](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L824)

Environment variables exposed to the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`environmentVariables`](CreateCanisterOptions.md#environmentvariables)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:775](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L775)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [packages/pic/src/pocket-ic-types.ts:658](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L658)

The interface factory to use for the [Actor](Actor.md).

***

### logMemoryLimit?

> `optional` **logMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:797](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L797)

The log memory limit of the canister in bytes.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`logMemoryLimit`](CreateCanisterOptions.md#logmemorylimit)

***

### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:792](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L792)

Who can read the canister's logs. Defaults to its controllers.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`logVisibility`](CreateCanisterOptions.md#logvisibility)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:770](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L770)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### minimumIncomingCanisterCallCycles?

> `optional` **minimumIncomingCanisterCallCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:787](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L787)

The minimum cycles that calls from other canisters must attach.
Calls attaching fewer cycles are rejected and refunded.
Ingress messages and calls from the canister itself are not affected.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`minimumIncomingCanisterCallCycles`](CreateCanisterOptions.md#minimumincomingcanistercallcycles)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:780](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L780)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:677](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L677)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### snapshotVisibility?

> `optional` **snapshotVisibility**: [`SnapshotVisibility`](../type-aliases/SnapshotVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:802](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L802)

Who can list and read the canister's snapshots. Defaults to its controllers.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`snapshotVisibility`](CreateCanisterOptions.md#snapshotvisibility)

***

### statusVisibility?

> `optional` **statusVisibility**: [`StatusVisibility`](../type-aliases/StatusVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:808](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L808)

Who can read the canister's status. Defaults to its controllers.
The canister itself can always read it.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`statusVisibility`](CreateCanisterOptions.md#statusvisibility)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:855](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L855)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:849](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L849)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:665](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L665)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

***

### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:813](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L813)

The WASM memory limit of the canister in bytes.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`wasmMemoryLimit`](CreateCanisterOptions.md#wasmmemorylimit)

***

### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:819](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L819)

The WASM memory threshold of the canister in bytes.
The canister_on_low_wasm_memory function will be called when the canister's remaining wasm memory is below this threshold.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`wasmMemoryThreshold`](CreateCanisterOptions.md#wasmmemorythreshold)

---
title: FetchCanisterLogsOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1814](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1814)

Options for fetching canister logs.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1818](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1818)

The Principal of the canister to fetch logs for.

***

### filter?

> `optional` **filter**: [`CanisterLogFilter`](../type-aliases/CanisterLogFilter.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1835](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1835)

Only return the log records in the given range.
Defaults to all log records.

***

### sender

> **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1829](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1829)

The Principal to send the request as.

By default, only a canister's controllers can read its logs. Other principals,
including the anonymous principal, need the canister's
[log visibility](https://docs.internetcomputer.org/guides/canister-management/settings/#log-visibility)
to allow them, e.g. `logVisibility: { public: null }` or
`logVisibility: { allowedViewers: [principal] }` in [PocketIc.updateCanisterSettings](../classes/PocketIc.md#updatecanistersettings).

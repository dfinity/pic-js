---
title: CanisterLogTimestampFilter
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1868](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1868)

Selects the log records whose timestamp is in the range `[start, end)`.

## Properties

### end

> **end**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1882](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1882)

The timestamp to stop before, in nanoseconds since epoch (exclusive).

***

### start

> **start**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1877](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1877)

The first timestamp to return, in nanoseconds since epoch (inclusive).

***

### type

> **type**: `"byTimestampNanos"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1872](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1872)

Filters by log record timestamp.

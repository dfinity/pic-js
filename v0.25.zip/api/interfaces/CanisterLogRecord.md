---
title: CanisterLogRecord
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1888](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1888)

A canister log record.

## Properties

### content

> **content**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1902](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1902)

The content of the log record.

***

### idx

> **idx**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1892](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1892)

The index of the log record.

***

### timestampNanos

> **timestampNanos**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1897](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1897)

The timestamp of the log record in nanoseconds since epoch.

---
title: CanisterSnapshotOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1394](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1394)

Options for loading, or deleting, a snapshot of a canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Extended by

- [`DownloadCanisterSnapshotOptions`](DownloadCanisterSnapshotOptions.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1398](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1398)

The Principal of the canister the snapshot belongs to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1409](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1409)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### snapshotId

> **snapshotId**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1403](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1403)

The ID of the snapshot.

---
title: CanisterMemoryMetrics
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1145](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1145)

Memory usage of a canister, broken down by kind, in bytes.

## Properties

### canisterHistorySize

> **canisterHistorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1174](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1174)

The memory used to store the canister's history.

***

### customSectionsSize

> **customSectionsSize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1169](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1169)

The memory used by the custom sections of the canister's WASM module.

***

### globalMemorySize

> **globalMemorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1159](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1159)

The memory used by the canister's global variables.

***

### logMemoryStoreSize

> **logMemoryStoreSize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1189](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1189)

The memory used by the canister's logs.

***

### snapshotsSize

> **snapshotsSize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1184](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1184)

The memory used by all snapshots of the canister.

***

### stableMemorySize

> **stableMemorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1154](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1154)

The stable memory used by the canister.

***

### wasmBinarySize

> **wasmBinarySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1164](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1164)

The size of the installed WASM module as uploaded, e.g. compressed if it was gzipped.

***

### wasmChunkStoreSize

> **wasmChunkStoreSize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1179](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1179)

The memory used by the canister's WASM chunk store.

***

### wasmMemorySize

> **wasmMemorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1149](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1149)

The heap memory used by the canister's WebAssembly code.

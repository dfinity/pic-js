---
title: IngressStatusOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1618](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1618)

Options for fetching the status of a submitted update call.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### caller?

> `optional` **caller**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1623](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1623)

The Principal that submitted the call. If set and the call was submitted
by a different principal, the request is rejected.

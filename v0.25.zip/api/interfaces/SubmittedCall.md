---
title: SubmittedCall
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1597](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1597)

An update call submitted with [PocketIc.submitCall](../classes/PocketIc.md#submitcall).

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### effectivePrincipal

> **effectivePrincipal**: \{ `canisterId`: `Principal`; \} \| \{ `subnetId`: `Principal`; \} \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:1606](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1606)

The canister or subnet the call was routed by.

***

### messageId

> **messageId**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1601](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1601)

The ID of the call's ingress message.

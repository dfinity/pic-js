---
title: MakeLiveOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1914](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1914)

Options for making a PocketIC instance live, see [PocketIc.makeLive](../classes/PocketIc.md#makelive).

## Properties

### artificialDelayMs?

> `optional` **artificialDelayMs**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1924](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1924)

The minimum delay in milliseconds between consecutive rounds.
Slows down calls that wait for live mode to execute them: calls made
through the HTTP gateway, and calls submitted with [PocketIc.submitCall](../classes/PocketIc.md#submitcall)
whose result is checked with [PocketIc.ingressStatus](../classes/PocketIc.md#ingressstatus).
Calls made with an actor, a deferred actor, [PocketIc.updateCall](../classes/PocketIc.md#updatecall) or
[PocketIc.awaitCall](../classes/PocketIc.md#awaitcall) execute their rounds themselves and are not delayed.
Defaults to no delay.

***

### httpGateway?

> `optional` **httpGateway**: [`HttpGatewayConfig`](HttpGatewayConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1930](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1930)

The HTTP gateway to start. Not supported if the instance was created
with [CreateInstanceOptions.httpGateway](CreateInstanceOptions.md#httpgateway), whose gateway is used instead.

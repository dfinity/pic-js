---
title: DefiniteCanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1199](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1199)

The settings of a canister, with every setting resolved to its current value,
as returned by the management canister's `canister_status` method.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### computeAllocation

> **computeAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1208](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1208)

The compute allocation of the canister, as a percentage between 0 and 100.

***

### controllers

> **controllers**: `Principal`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:1203](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1203)

The controllers of the canister.

***

### environmentVariables

> **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:1263](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1263)

The environment variables exposed to the canister.

***

### freezingThreshold

> **freezingThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1218](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1218)

The freezing threshold of the canister in seconds.

***

### logMemoryLimit

> **logMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1238](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1238)

The log memory limit of the canister in bytes.

***

### logVisibility

> **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1233](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1233)

Who can read the canister's logs.

***

### memoryAllocation

> **memoryAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1213](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1213)

The memory allocation of the canister in bytes.

***

### minimumIncomingCanisterCallCycles

> **minimumIncomingCanisterCallCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1228](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1228)

The minimum cycles that calls from other canisters must attach.

***

### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1223](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1223)

The upper limit on the canister's reserved cycles.

***

### snapshotVisibility

> **snapshotVisibility**: [`SnapshotVisibility`](../type-aliases/SnapshotVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1243](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1243)

Who can list and read the canister's snapshots.

***

### statusVisibility

> **statusVisibility**: [`StatusVisibility`](../type-aliases/StatusVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1248](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1248)

Who can read the canister's status.

***

### wasmMemoryLimit

> **wasmMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1253](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1253)

The WASM memory limit of the canister in bytes, or 0 for no limit.

***

### wasmMemoryThreshold

> **wasmMemoryThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1258](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1258)

The WASM memory threshold of the canister in bytes.

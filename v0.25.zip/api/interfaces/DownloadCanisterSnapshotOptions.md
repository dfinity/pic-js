---
title: DownloadCanisterSnapshotOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1438](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1438)

Options for downloading a snapshot of a canister to a directory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Extends

- [`CanisterSnapshotOptions`](CanisterSnapshotOptions.md)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1398](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1398)

The Principal of the canister the snapshot belongs to.

#### Inherited from

[`CanisterSnapshotOptions`](CanisterSnapshotOptions.md).[`canisterId`](CanisterSnapshotOptions.md#canisterid)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1450](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1450)

The Principal to send the request as.
Defaults to the anonymous principal.
It must be a controller unless the canister's snapshot visibility allows it.

#### Overrides

[`CanisterSnapshotOptions`](CanisterSnapshotOptions.md).[`sender`](CanisterSnapshotOptions.md#sender)

***

### snapshotDir

> **snapshotDir**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1443](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1443)

The directory to download the snapshot to, on the machine running the
PocketIC server. It must be empty or not exist yet.

***

### snapshotId

> **snapshotId**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1403](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1403)

The ID of the snapshot.

#### Inherited from

[`CanisterSnapshotOptions`](CanisterSnapshotOptions.md).[`snapshotId`](CanisterSnapshotOptions.md#snapshotid)

---
title: HttpGatewayConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:198](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L198)

Options for the HTTP gateway created together with a PocketIC instance.

## Properties

### domains?

> `optional` **domains**: `string`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:212](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L212)

The domains the gateway serves canisters on. Defaults to `localhost`.

***

### httpsConfig?

> `optional` **httpsConfig**: [`HttpsConfig`](HttpsConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:217](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L217)

Serves the gateway over HTTPS with the given certificate and key.

***

### ipAddr?

> `optional` **ipAddr**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:202](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L202)

The IP address the gateway listens on. Defaults to `127.0.0.1`.

***

### port?

> `optional` **port**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:207](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L207)

The port the gateway listens on. Defaults to a free port.

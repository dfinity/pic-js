---
title: CanisterLogIdxFilter
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1848](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1848)

Selects the log records whose index is in the range `[start, end)`.

## Properties

### end

> **end**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1862](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1862)

The index to stop before (exclusive).

***

### start

> **start**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1857](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1857)

The first index to return (inclusive).

***

### type

> **type**: `"byIdx"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1852](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1852)

Filters by log record index.

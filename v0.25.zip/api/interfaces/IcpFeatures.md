---
title: IcpFeatures
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:482](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L482)

Specifies ICP features enabled by deploying their corresponding system canisters
when creating a PocketIC instance and keeping them up to date during the PocketIC instance lifetime.
The subnets to which the corresponding system canisters are deployed must be empty.
An ICP feature is enabled if its `IcpFeaturesConfig` is provided, i.e., if the corresponding field is set.

## Properties

### bitcoin?

> `optional` **bitcoin**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:530](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L530)

Deploys the Bitcoin canister under the Bitcoin testnet canister ID
`g4xu7-jiaaa-aaaan-aaaaq-cai`, configured for the regtest network.
It syncs with the `bitcoind` nodes given by [CreateInstanceOptions.bitcoindAddrs](CreateInstanceOptions.md#bitcoindaddrs).

***

### canisterMigration?

> `optional` **canisterMigration**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:542](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L542)

Deploys the canister migration orchestrator canister on the NNS subnet.

***

### cyclesMinting?

> `optional` **cyclesMinting**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:494](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L494)

Deploys the NNS cycles minting canister, sets ICP/XDR conversion rate, and keeps its subnet lists in sync with PocketIC topology.
If enabled, the default timestamp of a PocketIC instance is set to 10 May 2021 10:00:01 AM CEST
(the smallest value that is strictly larger than the default timestamp hard-coded in the CMC state).

***

### cyclesToken?

> `optional` **cyclesToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:502](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L502)

Deploys the cycles ledger and index canisters and initializes the cycles account of the anonymous principal with 2^127 - 1 cycles.

***

### dogecoin?

> `optional` **dogecoin**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:537](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L537)

Deploys the Dogecoin canister under its mainnet canister ID
`gordg-fyaaa-aaaan-aaadq-cai`, configured for the regtest network.
It syncs with the `dogecoind` nodes given by [CreateInstanceOptions.dogecoindAddrs](CreateInstanceOptions.md#dogecoindaddrs).

***

### icpToken?

> `optional` **icpToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:498](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L498)

Deploys the ICP ledger and index canisters and initializes the ICP account of the anonymous principal with 1,000,000,000 ICP.

***

### ii?

> `optional` **ii**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:517](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L517)

Deploys the Internet Identity backend and frontend canisters.
Requires [CreateInstanceOptions.httpGateway](CreateInstanceOptions.md#httpgateway).

***

### nnsGovernance?

> `optional` **nnsGovernance**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:507](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L507)

Deploys the NNS governance and root canisters and sets up an initial NNS neuron with 1 ICP stake.
The initial NNS neuron is controlled by the anonymous principal.

***

### nnsUi?

> `optional` **nnsUi**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:523](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L523)

Deploys the NNS frontend dapp.
Requires [CreateInstanceOptions.httpGateway](CreateInstanceOptions.md#httpgateway) and the `cyclesMinting`,
`icpToken`, `nnsGovernance`, `sns` and `ii` features.

***

### registry?

> `optional` **registry**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:488](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L488)

Deploys the NNS registry canister and keeps its content in sync with registry used internally by PocketIC.
Note. The registry used internally by PocketIC is not updated after changing the registry stored in the registry canister
(e.g., after executing an NNS proposal mutating the registry).

***

### sns?

> `optional` **sns**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:512](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L512)

Deploys the SNS-W and aggregator canisters, sets up the SNS subnet list in the SNS-W canister according to PocketIC topology,
and uploads the SNS canister WASMs to the SNS-W canister.

---
title: SenderInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1498](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1498)

Sender information attached to a canister call.

This is passed through to the canister, which can inspect it via the
`msg_caller_info_data` and `msg_caller_info_signer` system APIs. PocketIC
does not validate or verify anything; it simply forwards both fields for
canister inspection, mocking the signer's signature.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### info

> **info**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1502](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1502)

An arbitrary binary blob of sender information.

***

### signer

> **signer**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1507](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1507)

The Principal of the canister whose signature will be mocked.

---
title: HttpsConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:223](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L223)

Paths to the certificate and key used to serve an HTTP gateway over HTTPS.

## Properties

### certPath

> **certPath**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:227](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L227)

The path to the PEM-encoded certificate chain, on the machine running the PocketIC server.

***

### keyPath

> **keyPath**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:232](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L232)

The path to the PEM-encoded private key, on the machine running the PocketIC server.

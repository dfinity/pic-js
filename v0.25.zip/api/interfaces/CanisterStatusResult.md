---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1273](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1273)

The result of querying the status of a canister,
as returned by the management canister's `canister_status` method.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1315](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1315)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1325](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1325)

The amount of cycles burned per day when idle.

***

### memoryMetrics

> **memoryMetrics**: [`CanisterMemoryMetrics`](CanisterMemoryMetrics.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1310](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1310)

The memory usage of the canister by kind, see [CanisterMemoryMetrics](CanisterMemoryMetrics.md).

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1305](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1305)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:1300](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1300)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1330](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1330)

Query call statistics for the canister.

***

### readyForMigration

> **readyForMigration**: `boolean`

Defined in: [packages/pic/src/pocket-ic-types.ts:1283](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1283)

Whether the canister's queues are empty and its streams flushed.
Only meaningful while the canister is stopped.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1320](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1320)

The reserved cycles of the canister.

***

### settings

> **settings**: [`DefiniteCanisterSettings`](DefiniteCanisterSettings.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1295](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1295)

The settings of the canister, see [DefiniteCanisterSettings](DefiniteCanisterSettings.md).

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1277](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1277)

The current status of the canister.

***

### version

> **version**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1290](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1290)

The canister version. It increases with every change to the canister's code,
settings, running status, cycles balance or memory, including every
successful execution of an update method, callback, heartbeat or timer.

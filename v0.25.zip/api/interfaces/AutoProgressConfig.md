---
title: AutoProgressConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:174](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L174)

Options for making an instance live when it is created,
see [CreateInstanceOptions.autoProgress](CreateInstanceOptions.md#autoprogress).

## Properties

### artificialDelayMs?

> `optional` **artificialDelayMs**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:179](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L179)

The minimum delay in milliseconds between consecutive rounds,
see [MakeLiveOptions.artificialDelayMs](MakeLiveOptions.md#artificialdelayms). Defaults to no delay.

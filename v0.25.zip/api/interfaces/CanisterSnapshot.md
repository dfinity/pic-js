---
title: CanisterSnapshot
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1342](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1342)

A snapshot of a canister.

## Properties

### id

> **id**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1346](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1346)

The ID of the snapshot.

***

### takenAtTimestamp

> **takenAtTimestamp**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1351](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1351)

When the snapshot was taken, in nanoseconds since the Unix epoch.

***

### totalSize

> **totalSize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1356](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1356)

The size of the snapshot in bytes.

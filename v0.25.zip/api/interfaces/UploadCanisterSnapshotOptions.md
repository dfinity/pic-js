---
title: UploadCanisterSnapshotOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1459](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1459)

Options for uploading a snapshot of a canister from a directory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1463](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1463)

The Principal of the canister to upload the snapshot to.

***

### replaceSnapshot?

> `optional` **replaceSnapshot**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:1474](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1474)

The ID of an existing snapshot to replace with the uploaded one.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1480](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1480)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### snapshotDir

> **snapshotDir**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1469](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1469)

The directory to upload the snapshot from, on the machine running the
PocketIC server, as written by [PocketIc.downloadCanisterSnapshot](../classes/PocketIc.md#downloadcanistersnapshot).

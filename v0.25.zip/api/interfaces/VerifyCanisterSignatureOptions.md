---
title: VerifyCanisterSignatureOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1635](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1635)

Options for verifying a canister signature.

## Properties

### message

> **message**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1639](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1639)

The signed message.

***

### publicKey

> **publicKey**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1650](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1650)

The DER-encoded canister signature public key, derived from the
signing canister's ID and a seed.

***

### rootKey

> **rootKey**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1656](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1656)

The DER-encoded root key of the network, e.g. the public key of the
NNS subnet, see [PocketIc.getPubKey](../classes/PocketIc.md#getpubkey).

***

### signature

> **signature**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1644](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1644)

The canister signature, a CBOR-encoded certificate and hash tree.

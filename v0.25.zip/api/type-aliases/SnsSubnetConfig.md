---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:292](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L292)

Options for creating an SNS subnet.

---
title: TestThresholdKeysSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **TestThresholdKeysSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:328](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L328)

Options for a test threshold keys subnet's state.

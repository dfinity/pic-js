---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:302](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L302)

Options for creating an II subnet.

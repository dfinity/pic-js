---
title: LogLevel
editUrl: false
next: true
prev: true
---

> **LogLevel** = `"critical"` \| `"error"` \| `"warn"` \| `"info"` \| `"debug"` \| `"trace"`

Defined in: [packages/pic/src/pocket-ic-types.ts:187](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L187)

The log level of a PocketIC instance's replica.

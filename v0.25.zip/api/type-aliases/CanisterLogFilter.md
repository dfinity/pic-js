---
title: CanisterLogFilter
editUrl: false
next: true
prev: true
---

> **CanisterLogFilter** = [`CanisterLogIdxFilter`](../interfaces/CanisterLogIdxFilter.md) \| [`CanisterLogTimestampFilter`](../interfaces/CanisterLogTimestampFilter.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1841](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L1841)

A range of canister log records to fetch, see [FetchCanisterLogsOptions.filter](../interfaces/FetchCanisterLogsOptions.md#filter).

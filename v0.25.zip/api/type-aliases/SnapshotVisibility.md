---
title: SnapshotVisibility
editUrl: false
next: true
prev: true
---

> **SnapshotVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:733](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L733)

Snapshot visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

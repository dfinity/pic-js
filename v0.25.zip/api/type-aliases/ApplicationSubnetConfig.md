---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\> & `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:353](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L353)

Options for creating an application subnet.

## Type Declaration

### costSchedule?

> `optional` **costSchedule**: [`CanisterCyclesCostSchedule`](../enumerations/CanisterCyclesCostSchedule.md)

The canister cycles cost schedule for the subnet.
Defaults to [CanisterCyclesCostSchedule.Normal](../enumerations/CanisterCyclesCostSchedule.md#normal).

Only supported on application subnets. The PocketIC server will reject
non-default values on other subnet kinds.

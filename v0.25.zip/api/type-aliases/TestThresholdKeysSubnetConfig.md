---
title: TestThresholdKeysSubnetConfig
editUrl: false
next: true
prev: true
---

> **TestThresholdKeysSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`TestThresholdKeysSubnetStateConfig`](TestThresholdKeysSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:322](https://github.com/dfinity/pic-js/blob/e762059a9595e12eb0e648adff80a37c84ceda8b/packages/pic/src/pocket-ic-types.ts#L322)

Options for creating a test threshold keys subnet.

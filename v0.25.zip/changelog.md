---
title: Changelog
editUrl: false
next: true
prev: true
---


## 0.25.0 (2026-10-02)

### Feat

- **pic**: support the remaining instance options (#318)
- **pic**: add options to makeLive (#314)
- **pic**: support canister snapshots (#310)
- **pic**: add the missing canister lifecycle methods (#311)
- **pic**: complete the canister settings and status, check the live spec (#309)

### Fix

- **pic**: reject a deferred call's promise when the call fails (#315)

## 0.24.0 (2026-09-25)

### BREAKING CHANGE

- `createActor` and `createDeferredActor` take an options
object instead of positional arguments. Replace
`pic.createActor<T>(idlFactory, canisterId)` with `pic.createActor<T>({
idlFactory, canisterId })`, and likewise for `createDeferredActor`. To
call as a principal other than anonymous, pass `sender` instead of
calling `setPrincipal` afterwards.
- PicJS downloads PocketIC v16 by default. Tests that
assert specific auto-allocated canister IDs, or cycle balances after
only a few ticks, may need updating.
- `@dfinity/pic` now requires `@icp-sdk/core` v6 as a
peer dependency, and NodeJS >= 22.12. Projects must depend on
`@icp-sdk/core@^6` directly (Yarn does not install it automatically).
Consumers testing with Jest must also widen `transformIgnorePatterns` so
that `@noble`/`@scure` are transformed — see the Jest guide for the
required config.

### Feat

- **pic**: add the test threshold keys subnet, restoring test_key_1 (#297)
- **pic**: take an options object in createActor and createDeferredActor (#296)
- **pic**: add fetchCanisterLogs (#235)
- **pic**: create the HTTP gateway together with the instance (#295)
- **pic**: bump PocketIC to v16 (#294)
- **pic**: require @icp-sdk/core v6 as a peer dependency (#291)

### Note

- PocketIC simulates mainnet threshold keys: `test_key_1` is held by the test threshold keys subnet (`testThresholdKeys`), and `key_1` by the II and Fiduciary subnets. `dfx_test_key` is no longer needed.

## 0.23.0 (2026-08-03)

### Feat

- **pic**: add ttl option to PocketIcServer.start (#278)
- **pic**: support overriding the PocketIC binary path (#276)

## 0.22.0 (2026-06-09)

### Feat

- **pic**: Update to v14, support disableIngressValidation and senderInfo (#271)
- **pic**: Allow specifying PIC version (#266)
- **pic**: Use arm64 pic binaries (#268)
- **pic**: add costSchedule option and bump PocketIC to v13 (#264)

## 0.21.0 (2026-03-18)

### Feat

- **pic**: add IC spec drift detection and update canister settings (#255)

### Fix

- **pic**: use await_ingress_message endpoint to fix update call performance (#257)

## 0.20.0 (2026-03-12)

### Feat

- update canister settings to match spec (#251)

### Fix

- **pic**: include request path in PocketIC server error messages (#70) (#249)

## 0.19.0 (2026-03-10)

### Feat

- **pic**: add chunked WASM upload and canisterStatus method (#239)
- add http gateway support (#233)
- bump PocketIC server to v12.0.0 (#231)

### Fix

- **pic**: fail immediately on non-retryable PocketIC server errors (#242)

## 0.18.0 (2026-01-21)

### BREAKING CHANGE

- Reverts "introduce a new `rounds` option for `awaitCall` method on `PocketIcClient` (#223)"

### Feat

- Introduce `ingressMaxRetries` to configure how many rounds an instance will
wait for update calls to complete before timing out (#227)

## 0.17.2 (2026-01-08)

### Feat

- introduce a new `rounds` option for `awaitCall` method on `PocketIcClient` (#223)
- bump icp-sdk/core to v5 (#221)

## 0.17.1 (2025-12-15)

## 0.17.0 (2025-12-11)

### Feat

- replace `@dfinity/*` deps with `@icp-sdk/core` (#199)
- `getDefaultEffectiveCanisterId` method in `PocketIc` class (#209)
- switch to `Uint8Array` for all buffers (#202)
- bump PocketIC server to v11.0.0 (#196)

### Fix

- use bigint for `addCycles` and `getCyclesBalance` (#208)

## 0.16.1 (2025-09-22)

### Fix

- docs typos and exports (#183)

## 0.16.0 (2025-09-17)

### Feat

- upgrade options on install canister code (#173)

### Fix

- increase poll timeout (#175)

## 0.15.0 (2025-09-16)

### Feat

- add `icpFeatures` field (#167)

## 0.14.1 (2025-09-12)

### Fix

- readme links and install instructions (#164)

## 0.14.0 (2025-09-12)

### BREAKING CHANGE

- Moves `@dfinity/agent`, `@dfinity/candid`,
`@dfinity/identity` and `@dfinity/principal` from `peerDependencies` to
`dependencies`
- `nonmainnetFeatures` in `CreateInstanceRequest` is
renamed to `icpConfig` and is now a record with multiple configuration
options to override

### Feat

- bump agent-js deps to v3 (#158)
- make pic-js compatible with server v10.0.0 (#147)

### Fix

- set the create-prs environment (#149)
- state copy to not include parent folder (#134)

### Refactor

- poll ingress messages instead of awaiting them (#137)

## 0.13.1 (2025-05-07)

## 0.13.0 (2025-04-29)

### BREAKING CHANGE

- `FromPathSubnetStateConfig` and the `FromPath` variant
of `state_config` in `EncodedSubnetConfig` no longer take a `subnet_id`.

### Feat

- update to PocketIC server v9.0.0 (#120)

## 0.12.0 (2025-04-07)

## 0.12.0b0 (2025-04-01)

### Feat

- add support for certified time endpoint (#109)
- update dependencies (#106)
- upgrade to pocketic version 8.0.0 (#96)
- add support get controllers and get topology endpoints
- update dependencies

### Fix

- **pocket-ic-server.ts**: switch from --pid to --port-file for pic server

## 0.10.0 (2024-11-27)

### Feat

- add support for mocking https outcalls

## 0.10.0-b0 (2024-10-07)

### Feat

- upgrade to server v6
- upgrade pic server to v5

## 0.9.0 (2024-07-01)

## 0.9.0-b0 (2024-05-06)

### Feat

- upgrade to pic server v4

## 0.8.1 (2024-04-27)

## 0.8.1-b0 (2024-04-27)

### Fix

- pipe unwanted logs to /dev/null

## 0.8.0 (2024-04-27)

## 0.8.0-b1 (2024-04-22)

### Feat

- add http2 support

## 0.8.0-b0 (2024-04-21)

### Feat

- add logging support
- separate pic server management from instance management

## 0.7.0 (2024-03-17)

## 0.7.0-b0 (2024-03-17)

### Feat

- enable direct canister calls

## 0.6.1 (2024-03-15)

## 0.6.1-b1 (2024-03-15)

### Fix

- get pub key endpoint params encoded incorrectly
- unable to start picjs server on macos
- build docs only when release_latest is successful
- move docs build and deployment to release workflow

## 0.6.1-b0 (2024-03-07)

### Fix

- removed fetchRootKey in favor of getPubKey, which accepts a subnet Id

## 0.6.0 (2024-03-03)

### Feat

- add support for nns subnet init

## 0.5.0 (2024-02-24)

### Feat

- update agent-js and pocket-ic dependencies

## 0.4.0 (2024-02-19)

### Feat

- add canister stop and start methods

## 0.3.0 (2024-02-12)

## 0.3.0-b4 (2024-02-12)

### Fix

- canister settings encoding

## 0.3.0-b3 (2024-02-12)

### Fix

- propogate sender principal correctly when setting up canister

## 0.3.0-b2 (2024-02-12)

## 0.3.0-b1 (2024-02-12)

### Feat

- add update canister settings method
- upgrade to pocket-ic v3
- upgrade to pic server 2.0.1

## 0.3.0-b0 (2024-01-28)

### Feat

- accept ArrayBufferLike instead of Uint8Array to be more compatible with agent-js & co libraries
- throw a more helpful error is devs interact with a pic instance after tearing it down
- add ability to tick multiple times

### Fix

- updated dependencies on dfinity packages
- updated dependencies on dfinity packages

### Refactor

- use auto-generated idl for management canister

## 0.2.1 (2024-01-21)

## 0.2.1-b2 (2024-01-11)

### Feat

- update versions of @dfinity dependencies

## 0.2.1-b1 (2024-01-07)

### Fix

- update file permission for pocket-ic executable in case package manager has moved it

## 0.2.1-b0 (2023-12-14)

### Fix

- client refuses to start on MacOS ARM chips that are also running NodeJS on ARM architecture

## 0.2.0 (2023-11-06)

## 0.2.0-b3 (2023-11-06)

### Fix

- set processing time header on set_stable_memory header
- get stable memory function returning incorrect type

## 0.2.0-b2 (2023-11-03)

### Feat

- add functions to get and set stable memory

## 0.2.0-b1 (2023-11-02)

### Feat

- add canister code management functions

## 0.2.0-b0 (2023-11-02)

### Feat

- add deterministic and random identity generation functions
- add method to set identity on actor

## 0.1.0 (2023-11-02)

### Feat

- include pic binary in package using postinstall script
- initial commit

---
title: createActorClass
editUrl: false
next: true
prev: true
---

> **createActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [packages/pic/src/pocket-ic-actor.ts:90](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-actor.ts#L90)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

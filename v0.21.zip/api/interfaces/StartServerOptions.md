---
title: StartServerOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-server-types.ts:4](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-server-types.ts#L4)

Options for starting a PocketIC server.

## Properties

### showCanisterLogs?

> `optional` **showCanisterLogs**: `boolean`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:13](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-server-types.ts#L13)

Whether to pipe the canister logs to the parent process's stderr.

***

### showRuntimeLogs?

> `optional` **showRuntimeLogs**: `boolean`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:8](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-server-types.ts#L8)

Whether to pipe the runtimes's logs to the parent process's stdout.

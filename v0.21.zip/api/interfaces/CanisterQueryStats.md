---
title: CanisterQueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:801](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L801)

Query statistics for a canister.

## Properties

### numCallsTotal

> **numCallsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:802](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L802)

***

### numInstructionsTotal

> **numInstructionsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:803](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L803)

***

### requestPayloadBytesTotal

> **requestPayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:804](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L804)

***

### responsePayloadBytesTotal

> **responsePayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:805](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L805)

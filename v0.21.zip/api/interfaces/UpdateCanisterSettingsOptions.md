---
title: UpdateCanisterSettingsOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:754](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L754)

Options for updating the settings of a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extends

- `Partial`\<[`CanisterSettings`](CanisterSettings.md)\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:758](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L758)

The Principal of the canister to update the settings for.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:510](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L510)

The compute allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`computeAllocation`](CanisterSettings.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:505](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L505)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`controllers`](CanisterSettings.md#controllers)

***

### environmentVariables?

> `optional` **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:556](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L556)

Environment variables exposed to the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`environmentVariables`](CanisterSettings.md#environmentvariables)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:520](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L520)

The freezing threshold of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`freezingThreshold`](CanisterSettings.md#freezingthreshold)

***

### logMemoryLimit?

> `optional` **logMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:540](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L540)

The log memory limit of the canister in bytes.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`logMemoryLimit`](CanisterSettings.md#logmemorylimit)

***

### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:530](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L530)

The log visibility of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`logVisibility`](CanisterSettings.md#logvisibility)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:515](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L515)

The memory allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`memoryAllocation`](CanisterSettings.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:525](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L525)

The reserved cycles limit of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`reservedCyclesLimit`](CanisterSettings.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:764](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L764)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### snapshotVisibility?

> `optional` **snapshotVisibility**: [`SnapshotVisibility`](../type-aliases/SnapshotVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:535](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L535)

The snapshot visibility of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`snapshotVisibility`](CanisterSettings.md#snapshotvisibility)

***

### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:545](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L545)

The WASM memory limit of the canister in bytes.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`wasmMemoryLimit`](CanisterSettings.md#wasmmemorylimit)

***

### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:551](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L551)

The WASM memory threshold of the canister in bytes.
The canister_on_low_wasm_memory function will be called when the canister's remaining wasm memory is below this threshold.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`wasmMemoryThreshold`](CanisterSettings.md#wasmmemorythreshold)

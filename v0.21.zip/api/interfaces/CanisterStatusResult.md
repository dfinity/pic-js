---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:817](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L817)

The result of querying the status of a canister.
This is a subset of the IC management canister `canister_status` response.
Some fields (e.g. `snapshotVisibility`, `logMemoryLimit`, `memoryMetrics`)
are not yet included because the PocketIC server does not return them.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:851](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L851)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:861](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L861)

The amount of cycles burned per day when idle.

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:846](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L846)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:841](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L841)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:866](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L866)

Query call statistics for the canister.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:856](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L856)

The reserved cycles of the canister.

***

### settings

> **settings**: `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:826](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L826)

The definite settings of the canister.

#### computeAllocation

> **computeAllocation**: `bigint`

#### controllers

> **controllers**: `Principal`[]

#### environmentVariables

> **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

#### freezingThreshold

> **freezingThreshold**: `bigint`

#### logVisibility

> **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

#### memoryAllocation

> **memoryAllocation**: `bigint`

#### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

#### wasmMemoryLimit

> **wasmMemoryLimit**: `bigint`

#### wasmMemoryThreshold

> **wasmMemoryThreshold**: `bigint`

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:821](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L821)

The current status of the canister.

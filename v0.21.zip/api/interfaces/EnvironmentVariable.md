---
title: EnvironmentVariable
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:467](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L467)

Environment variable for canister settings.

## Properties

### name

> **name**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:468](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L468)

***

### value

> **value**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:469](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L469)

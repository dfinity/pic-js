---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:417](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L417)

Options for setting up a canister.

## Extends

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:434](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L434)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty Uint8Array.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:510](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L510)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:505](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L505)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:570](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L570)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### environmentVariables?

> `optional` **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:556](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L556)

Environment variables exposed to the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`environmentVariables`](CreateCanisterOptions.md#environmentvariables)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:520](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L520)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [packages/pic/src/pocket-ic-types.ts:421](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L421)

The interface factory to use for the [Actor](Actor.md).

***

### logMemoryLimit?

> `optional` **logMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:540](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L540)

The log memory limit of the canister in bytes.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`logMemoryLimit`](CreateCanisterOptions.md#logmemorylimit)

***

### logVisibility?

> `optional` **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:530](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L530)

The log visibility of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`logVisibility`](CreateCanisterOptions.md#logvisibility)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:515](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L515)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:525](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L525)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:440](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L440)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### snapshotVisibility?

> `optional` **snapshotVisibility**: [`SnapshotVisibility`](../type-aliases/SnapshotVisibility.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:535](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L535)

The snapshot visibility of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`snapshotVisibility`](CreateCanisterOptions.md#snapshotvisibility)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:587](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L587)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:581](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L581)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:428](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L428)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

***

### wasmMemoryLimit?

> `optional` **wasmMemoryLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:545](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L545)

The WASM memory limit of the canister in bytes.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`wasmMemoryLimit`](CreateCanisterOptions.md#wasmmemorylimit)

***

### wasmMemoryThreshold?

> `optional` **wasmMemoryThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:551](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L551)

The WASM memory threshold of the canister in bytes.
The canister_on_low_wasm_memory function will be called when the canister's remaining wasm memory is below this threshold.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`wasmMemoryThreshold`](CreateCanisterOptions.md#wasmmemorythreshold)

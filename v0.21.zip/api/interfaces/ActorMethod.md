---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-actor.ts:12](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-actor.ts#L12)

Typesafe method of a canister.

## Type Parameters

### Args

`Args` *extends* `any`[] = `any`[]

### Ret

`Ret` = `any`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/pic/src/pocket-ic-actor.ts:13](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-actor.ts#L13)

Typesafe method of a canister.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

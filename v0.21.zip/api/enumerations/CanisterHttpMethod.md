---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:993](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L993)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:997](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L997)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1007](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L1007)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1002](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L1002)

A POST request.

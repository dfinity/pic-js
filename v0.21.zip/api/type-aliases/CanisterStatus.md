---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

> **CanisterStatus** = \{ `running`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `stopped`: `null`; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:791](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L791)

The status of a canister.

---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [packages/pic/src/pocket-ic-types.ts:1013](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L1013)

An HTTP header for an HTTPS outcall.

---
title: LogVisibility
editUrl: false
next: true
prev: true
---

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:478](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L478)

Log visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

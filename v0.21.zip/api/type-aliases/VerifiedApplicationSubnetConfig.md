---
title: VerifiedApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`VerifiedApplicationSubnetStateConfig`](VerifiedApplicationSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:192](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L192)

Options for creating a verified application subnet.

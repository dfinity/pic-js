---
title: BitcoinSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:166](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L166)

Options for a Bitcoin subnet's state.

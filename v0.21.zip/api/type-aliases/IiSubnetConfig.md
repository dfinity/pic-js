---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:141](https://github.com/dfinity/pic-js/blob/afbeb2577b3a5a37bd940333ad9c126bd41ac5bd/packages/pic/src/pocket-ic-types.ts#L141)

Options for creating an II subnet.

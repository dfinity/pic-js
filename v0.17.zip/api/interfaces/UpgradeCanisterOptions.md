---
title: UpgradeCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:648](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L648)

Options for upgrading a given canister with a WASM module.
This will reset the canister's heap, but preserve stable memory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:664](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L664)

Candid encoded argument to pass to the canister's init function.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:652](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L652)

The Principal of the canister to upgrade.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:670](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L670)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### upgradeModeOptions?

> `optional` **upgradeModeOptions**: [`CanisterInstallModeUpgradeOptions`](CanisterInstallModeUpgradeOptions.md)

Defined in: [pocket-ic-types.ts:675](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L675)

The options to pass to the management canister's upgrade variant in the install code request.

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:659](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L659)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

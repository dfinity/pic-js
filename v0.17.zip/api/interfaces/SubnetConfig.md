---
title: SubnetConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:86](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L86)

Common options for creating a subnet.

## Type Parameters

### T

`T` *extends* [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md) = [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md)

## Properties

### enableBenchmarkingInstructionLimits?

> `optional` **enableBenchmarkingInstructionLimits**: `boolean`

Defined in: [pocket-ic-types.ts:101](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L101)

Whether to enable benchmarking instruction limits.
Defaults to `false`.

***

### enableDeterministicTimeSlicing?

> `optional` **enableDeterministicTimeSlicing**: `boolean`

Defined in: [pocket-ic-types.ts:95](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L95)

Whether to enable deterministic time slicing.
Defaults to `true`.

***

### state

> **state**: `T`

Defined in: [pocket-ic-types.ts:106](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L106)

The state configuration for the subnet.

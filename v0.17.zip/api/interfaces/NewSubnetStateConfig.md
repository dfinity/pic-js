---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:196](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L196)

Options for creating a new subnet an empty state.

## Properties

### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [pocket-ic-types.ts:200](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L200)

The type of subnet state to initialize the subnet with.

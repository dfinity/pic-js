---
title: UpdateCallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:744](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L744)

Options for making an update call to a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:765](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L765)

A Candid encoded argument to pass to the canister's method.
Defaults to an empty Uint8Array.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:754](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L754)

The Principal of the canister to update.

***

### method

> **method**: `string`

Defined in: [pocket-ic-types.ts:759](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L759)

The method to call on the canister.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:749](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L749)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:770](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L770)

The ID of the subnet that the canister resides on.

---
title: DeferredActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-deferred-actor.ts:8](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-deferred-actor.ts#L8)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **DeferredActorMethod**(...`args`): `Promise`\<() => `Promise`\<`Ret`\>\>

Defined in: [pocket-ic-deferred-actor.ts:12](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-deferred-actor.ts#L12)

## Parameters

### args

...`Args`

## Returns

`Promise`\<() => `Promise`\<`Ret`\>\>

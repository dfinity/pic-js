---
title: DeferredActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-deferred-actor.ts:8](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-deferred-actor.ts#L8)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **DeferredActorMethod**(...`args`): `Promise`\<() => `Promise`\<`Ret`\>\>

Defined in: [pocket-ic-deferred-actor.ts:12](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-deferred-actor.ts#L12)

## Parameters

### args

...`Args`

## Returns

`Promise`\<() => `Promise`\<`Ret`\>\>

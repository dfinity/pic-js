---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-actor.ts:12](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-actor.ts#L12)

Typesafe method of a canister.

## Type Parameters

### Args

`Args` *extends* `any`[] = `any`[]

### Ret

`Ret` = `any`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [pocket-ic-actor.ts:13](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-actor.ts#L13)

Typesafe method of a canister.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

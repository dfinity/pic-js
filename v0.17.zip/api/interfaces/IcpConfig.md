---
title: IcpConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:258](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L258)

Configures IC protocol properties.

## Properties

### betaFeatures?

> `optional` **betaFeatures**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:262](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L262)

Beta features (disabled on the ICP mainnet).

***

### canisterBacktrace?

> `optional` **canisterBacktrace**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:266](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L266)

Canister backtraces (enabled on the ICP mainnet).

***

### canisterExecutionRateLimiting?

> `optional` **canisterExecutionRateLimiting**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:275](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L275)

Rate-limiting of canister execution (enabled on the ICP mainnet).
Canister execution refers to instructions and memory writes here.

***

### functionNameLengthLimits?

> `optional` **functionNameLengthLimits**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:270](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L270)

Limits on function name length in canister WASM (enabled on the ICP mainnet).

---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:338](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L338)

The topology of a subnet.

## Properties

### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [pocket-ic-types.ts:357](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L357)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [pocket-ic-types.ts:342](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L342)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [pocket-ic-types.ts:352](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L352)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [pocket-ic-types.ts:347](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L347)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

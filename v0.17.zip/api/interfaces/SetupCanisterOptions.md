---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:410](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L410)

Options for setting up a canister.

## Extends

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:427](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L427)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty Uint8Array.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:471](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L471)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:466](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L466)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:500](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L500)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:481](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L481)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [pocket-ic-types.ts:414](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L414)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:476](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L476)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:486](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L486)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:433](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L433)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:517](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L517)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:511](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L511)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:421](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L421)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

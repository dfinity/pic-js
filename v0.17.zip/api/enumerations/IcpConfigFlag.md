---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:250](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L250)

Flag for configuration options in `IcpConfig`.

## Enumeration Members

### Disabled

> **Disabled**: `"Disabled"`

Defined in: [pocket-ic-types.ts:251](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L251)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [pocket-ic-types.ts:252](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L252)

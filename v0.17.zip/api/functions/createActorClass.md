---
title: createActorClass
editUrl: false
next: true
prev: true
---

> **createActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [pocket-ic-actor.ts:90](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-actor.ts#L90)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

---
title: SystemSubnetConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SystemSubnetStateConfig`](SystemSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:164](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L164)

Options for creating a system subnet.

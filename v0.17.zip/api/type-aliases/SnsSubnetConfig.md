---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:124](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L124)

Options for creating an SNS subnet.

---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.

## Type Parameters

### T

`T` = `object`

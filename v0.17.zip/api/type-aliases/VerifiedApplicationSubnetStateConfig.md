---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:191](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L191)

Options for a verified application subnet's state.

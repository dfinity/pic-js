---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:191](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L191)

Options for a verified application subnet's state.

---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [pocket-ic-types.ts:842](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L842)

An HTTP header for an HTTPS outcall.

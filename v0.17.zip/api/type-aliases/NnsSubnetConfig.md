---
title: NnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`NnsSubnetStateConfig`](NnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:112](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L112)

Options for creating an NNS subnet.

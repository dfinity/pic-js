---
title: FiduciarySubnetConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`FiduciarySubnetStateConfig`](FiduciarySubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:144](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L144)

Options for creating a Fiduciary subnet.

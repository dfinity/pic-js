---
title: FiduciarySubnetConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`FiduciarySubnetStateConfig`](FiduciarySubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:144](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L144)

Options for creating a Fiduciary subnet.

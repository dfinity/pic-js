---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:174](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L174)

Options for creating an application subnet.

---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:154](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L154)

Options for creating a Bitcoin subnet.

---
title: PocketIc
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic.ts:85](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L85)

This class represents the main PocketIC client.
It is responsible for interacting with the PocketIC server via the REST API.
See [PocketIcServer](PocketIcServer.md) for details on the server to use with this client.


The easist way to use PocketIC is to use [setupCanister](#setupcanister) convenience method:
```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const fixture = await pic.setupCanister<_SERVICE>({ idlFactory, wasmPath });
const { actor } = fixture;

// perform tests...

await pic.tearDown();
await picServer.stop();
```

If more control is needed, then the [createCanister](#createcanister), [installCode](#installcode) and
[createActor](#createactor) methods can be used directly:
```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const canisterId = await pic.createCanister();
await pic.installCode({ canisterId, wasm });
const actor = pic.createActor<_SERVICE>({ idlFactory, canisterId });

// perform tests...

await pic.tearDown();
await picServer.stop();
```

## Methods

### addCycles()

> **addCycles**(`canisterId`, `amount`): `Promise`\<`number`\>

Defined in: [pocket-ic.ts:1256](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1256)

Add cycles to the specified canister.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to add cycles to.

##### amount

`number`

The amount of cycles to add.

#### Returns

`Promise`\<`number`\>

The new cycle balance of the canister.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const newCyclesBalance = await pic.addCycles(canisterId, 10_000_000);

await pic.tearDown();
await picServer.stop();
```

***

### advanceCertifiedTime()

> **advanceCertifiedTime**(`duration`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:1033](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1033)

Advance the time of the IC by the given duration in milliseconds and
immediately have query calls and read state requests reflect the new time.

Use [advanceTime](#advancetime) to advance time without immediately reflecting the new time.

#### Parameters

##### duration

`number`

The duration to advance the time by.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const initialTime = await pic.getTime();
await pic.advanceCertifiedTime(1_000);

const newTime = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### advanceTime()

> **advanceTime**(`duration`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:1003](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1003)

Advance the time of the IC by the given duration in milliseconds.
[tick](#tick) should be called after calling this method in order for query calls
and read state requests to reflect the new time.

Use [advanceCertifiedTime](#advancecertifiedtime) to advance time and immediately have query calls and
read state requests reflect the new time.

#### Parameters

##### duration

`number`

The duration to advance the time by.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const initialTime = await pic.getTime();
await pic.advanceTime(1_000);
await pic.tick();

const newTime = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### createActor()

> **createActor**\<`T`\>(`interfaceFactory`, `canisterId`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [pocket-ic.ts:596](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L596)

Creates an [Actor](../interfaces/Actor.md) for the given canister.
An [Actor](../interfaces/Actor.md) is a typesafe class that implements the Candid interface of a canister.
To create a canister for the [Actor](../interfaces/Actor.md), see [createCanister](#createcanister).
For a more convenient way of creating a PocketIC instance,
creating a canister and installing code, see [setupCanister](#setupcanister).

#### Type Parameters

##### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

#### Parameters

##### interfaceFactory

`InterfaceFactory`

The InterfaceFactory to use for the [Actor](../interfaces/Actor.md).

##### canisterId

`Principal`

The Principal of the canister to create the [Actor](../interfaces/Actor.md) for.

#### Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

The [Actor](../interfaces/Actor.md) instance.

#### Typeparam

T The type of the [Actor](../interfaces/Actor.md). Must implement [ActorInterface](../type-aliases/ActorInterface.md).

#### See

 - [Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)
 - [InterfaceFactory](https://js.icp.build/core/latest/libs/candid/api/namespaces/idl/type-aliases/interfacefactory/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));
const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const canisterId = await pic.createCanister();
await pic.installCode({ canisterId, wasm });
const actor = pic.createActor<_SERVICE>({ idlFactory, canisterId });

await pic.tearDown();
await picServer.stop();
```

***

### createCanister()

> **createCanister**(`options`): `Promise`\<`Principal`\>

Defined in: [pocket-ic.ts:205](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L205)

Creates a new canister.
For a more convenient way of creating a PocketIC instance,
creating a canister and installing code, see [setupCanister](#setupcanister).

#### Parameters

##### options

[`CreateCanisterOptions`](../interfaces/CreateCanisterOptions.md) = `{}`

Options for creating the canister, see [CreateCanisterOptions](../interfaces/CreateCanisterOptions.md).

#### Returns

`Promise`\<`Principal`\>

The Principal of the newly created canister.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const canisterId = await pic.createCanister();

await pic.tearDown();
await picServer.stop();
```

***

### createDeferredActor()

> **createDeferredActor**\<`T`\>(`interfaceFactory`, `canisterId`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic.ts:631](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L631)

Creates a [DeferredActor](../type-aliases/DeferredActor.md) for the given canister.
A [DeferredActor](../type-aliases/DeferredActor.md) is a typesafe class that implements the Candid interface of a canister.

A [DeferredActor](../type-aliases/DeferredActor.md) in contrast to a normal [Actor](../interfaces/Actor.md) will submit the call to the PocketIc replica,
but the call will not be executed immediately. Instead, the calls are queued and a `Promise` is returned
by the [DeferredActor](../type-aliases/DeferredActor.md) that can be awaited to process the pending canister call.

To create a canister for the [DeferredActor](../type-aliases/DeferredActor.md), see [createCanister](#createcanister).
For a more convenient way of creating a PocketIC instance,
creating a canister and installing code, see [setupCanister](#setupcanister).

#### Type Parameters

##### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

#### Parameters

##### interfaceFactory

`InterfaceFactory`

The InterfaceFactory to use for the [DeferredActor](../type-aliases/DeferredActor.md).

##### canisterId

`Principal`

The Principal of the canister to create the [DeferredActor](../type-aliases/DeferredActor.md) for.

#### Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

The [DeferredActor](../type-aliases/DeferredActor.md) instance.

#### Typeparam

T The type of the [DeferredActor](../type-aliases/DeferredActor.md). Must implement [ActorInterface](../type-aliases/ActorInterface.md).

#### See

 - [Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)
 - [InterfaceFactory](https://js.icp.build/core/latest/libs/candid/api/namespaces/idl/type-aliases/interfacefactory/)

#### Example

```ts

```

***

### getApplicationSubnets()

> **getApplicationSubnets**(): `Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

Defined in: [pocket-ic.ts:1182](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1182)

Get all application subnet topologies for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

An array of subnet topologies for each application subnet
that exists on this instance's network.

***

### getBitcoinSubnet()

> **getBitcoinSubnet**(): `Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

Defined in: [pocket-ic.ts:1115](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1115)

Get the Bitcoin subnet topology for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

The subnet topology for the Bitcoin subnet,
if it exists on this instance's network.

***

### getCanisterSubnetId()

> **getCanisterSubnetId**(`canisterId`): `Promise`\<`null` \| `Principal`\>

Defined in: [pocket-ic.ts:1086](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1086)

Gets the subnet Id of the provided canister Id.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to get the subnet Id of.

#### Returns

`Promise`\<`null` \| `Principal`\>

The canister's subnet Id if the canister exists, `null` otherwise.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const subnetId = await pic.getCanisterSubnetId(canisterId);

await pic.tearDown();
await picServer.stop();
```

***

### getControllers()

> **getControllers**(`canisterId`): `Promise`\<`Principal`[]\>

Defined in: [pocket-ic.ts:817](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L817)

Get the controllers of the specified canister.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to get the controllers of.

#### Returns

`Promise`\<`Principal`[]\>

The controllers of the specified canister.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const controllers = await pic.getControllers(canisterId);

await pic.tearDown();
await picServer.stop();

***

### getCyclesBalance()

> **getCyclesBalance**(`canisterId`): `Promise`\<`number`\>

Defined in: [pocket-ic.ts:1225](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1225)

Gets the current cycle balance of the specified canister.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to check.

#### Returns

`Promise`\<`number`\>

The current cycles balance of the canister.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const cyclesBalance = await pic.getCyclesBalance(canisterId);

await pic.tearDown();
await picServer.stop();
```

***

### getFiduciarySubnet()

> **getFiduciarySubnet**(): `Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

Defined in: [pocket-ic.ts:1128](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1128)

Get the Fiduciary subnet topology for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

The subnet topology for the Fiduciary subnet,
if it exists on this instance's network.

***

### getInternetIdentitySubnet()

> **getInternetIdentitySubnet**(): `Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

Defined in: [pocket-ic.ts:1141](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1141)

Get the Internet Identity subnet topology for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

The subnet topology for the Internet Identity subnet,
if it exists on this instance's network.

***

### getNnsSubnet()

> **getNnsSubnet**(): `Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

Defined in: [pocket-ic.ts:1156](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1156)

Get the NNS subnet topology for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

The subnet topology for the NNS subnet,
if it exists on this instance's network.

***

### getPendingHttpsOutcalls()

> **getPendingHttpsOutcalls**(): `Promise`\<[`PendingHttpsOutcall`](../interfaces/PendingHttpsOutcall.md)[]\>

Defined in: [pocket-ic.ts:1381](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1381)

Get all pending HTTPS Outcalls across all subnets on this
PocketIC instance.

#### Returns

`Promise`\<[`PendingHttpsOutcall`](../interfaces/PendingHttpsOutcall.md)[]\>

An array of pending HTTPS Outcalls.

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

// queue the canister message that will send the HTTPS Outcall
const executeGoogleSearch = await deferredActor.google_search();

// tick for two rounds to allow the canister message to be processed
// and for the HTTPS Outcall to be queued
await pic.tick(2);

// get all queued HTTPS Outcalls
const pendingHttpsOutcalls = await pic.getPendingHttpsOutcalls();

// get the first pending HTTPS Outcall
const pendingGoogleSearchOutcall = pendingHttpsOutcalls[0];

// mock the HTTPS Outcall
await pic.mockPendingHttpsOutcall({
  requestId: pendingGoogleSearchOutcall.requestId,
  subnetId: pendingGoogleSearchOutcall.subnetId,
  response: {
    type: 'success',
    body: new TextEncoder().encode('Google search result'),
    statusCode: 200,
    headers: [],
  },
});

// finish executing the message, including the HTTPS Outcall
const result = await executeGoogleSearch();

await pic.tearDown();
await picServer.stop();
```

***

### getPubKey()

> **getPubKey**(`subnetId`): `Promise`\<`ArrayBufferLike`\>

Defined in: [pocket-ic.ts:1059](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1059)

Fetch the public key of the specified subnet.

#### Parameters

##### subnetId

`Principal`

The Principal of the subnet to fetch the public key of.

#### Returns

`Promise`\<`ArrayBufferLike`\>

The public key of the specified subnet.

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const subnets = pic.getApplicationSubnets();
const pubKey = await pic.getPubKey(subnets[0].id);

await pic.tearDown();
await picServer.stop();
```

***

### getSnsSubnet()

> **getSnsSubnet**(): `Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

Defined in: [pocket-ic.ts:1169](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1169)

Get the SNS subnet topology for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<`undefined` \| [`SubnetTopology`](../interfaces/SubnetTopology.md)\>

The subnet topology for the SNS subnet,
if it exists on this instance's network.

***

### getStableMemory()

> **getStableMemory**(`canisterId`): `Promise`\<`ArrayBufferLike`\>

Defined in: [pocket-ic.ts:1325](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1325)

Get the stable memory of a given canister.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to get the stable memory of.

#### Returns

`Promise`\<`ArrayBufferLike`\>

A blob containing the canister's stable memory.

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const stableMemory = await pic.getStableMemory(canisterId);

await pic.tearDown();
await picServer.stop();
```

***

### getSystemSubnets()

> **getSystemSubnets**(): `Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

Defined in: [pocket-ic.ts:1195](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1195)

Get all system subnet topologies for this instance's network.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

An array of subnet topologies for each system subnet
that exists on this instance's network.

***

### getTime()

> **getTime**(): `Promise`\<`number`\>

Defined in: [pocket-ic.ts:839](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L839)

Get the current time of the IC in milliseconds since the Unix epoch.

#### Returns

`Promise`\<`number`\>

The current time in milliseconds since the UNIX epoch.

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const time = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### getTopology()

> **getTopology**(): `Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

Defined in: [pocket-ic.ts:1102](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1102)

Get the topology of this instance's network.
The topology is a list of subnets, each with a type and a list of canister ID ranges
that can be deployed to that subnet.
The instance network topology is configured via the [create](#create) method.

#### Returns

`Promise`\<[`SubnetTopology`](../interfaces/SubnetTopology.md)[]\>

An array of subnet topologies, see [SubnetTopology](../interfaces/SubnetTopology.md).

***

### installCode()

> **installCode**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:363](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L363)

Installs the given WASM module to the provided canister.
To create a canister to install code to, see [createCanister](#createcanister).
For a more convenient way of creating a PocketIC instance,
creating a canister and installing code, see [setupCanister](#setupcanister).

#### Parameters

##### options

[`InstallCodeOptions`](../interfaces/InstallCodeOptions.md)

Options for installing the code, see [InstallCodeOptions](../interfaces/InstallCodeOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { resolve } from 'node:path';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));
const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.installCode({ canisterId, wasm });

await pic.tearDown();
await picServer.stop();
```

***

### mockPendingHttpsOutcall()

> **mockPendingHttpsOutcall**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:1432](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1432)

Mock a pending HTTPS Outcall.

#### Parameters

##### options

[`MockPendingHttpsOutcallOptions`](../interfaces/MockPendingHttpsOutcallOptions.md)

Options for mocking the pending HTTPS Outcall, see [MockPendingHttpsOutcallOptions](../interfaces/MockPendingHttpsOutcallOptions.md).

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

// queue the canister message that will send the HTTPS Outcall
const executeGoogleSearch = await deferredActor.google_search();

// tick for two rounds to allow the canister message to be processed
// and for the HTTPS Outcall to be queued
await pic.tick(2);

// get all queued HTTPS Outcalls
const pendingHttpsOutcalls = await pic.getPendingHttpsOutcalls();

// get the first pending HTTPS Outcall
const pendingGoogleSearchOutcall = pendingHttpsOutcalls[0];

// mock the HTTPS Outcall
await pic.mockPendingHttpsOutcall({
  requestId: pendingGoogleSearchOutcall.requestId,
  subnetId: pendingGoogleSearchOutcall.subnetId,
  response: {
    type: 'success',
    body: new TextEncoder().encode('Google search result'),
    statusCode: 200,
    headers: [],
  },
});

// finish executing the message, including the HTTPS Outcall
const result = await executeGoogleSearch();

await pic.tearDown();
await picServer.stop();
```

***

### queryCall()

> **queryCall**(`options`): `Promise`\<`ArrayBufferLike`\>

Defined in: [pocket-ic.ts:675](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L675)

Makes a query call to the given canister.

#### Parameters

##### options

[`QueryCallOptions`](../interfaces/QueryCallOptions.md)

Options for making the query call, see [QueryCallOptions](../interfaces/QueryCallOptions.md).

#### Returns

`Promise`\<`ArrayBufferLike`\>

The Candid-encoded response of the query call.

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

canisterId = await pic.createCanister({
  sender: controllerIdentity.getPrincipal(),
});
await pic.installCode({ canisterId, wasm });

const res = await pic.queryCall({
 canisterId,
 method: 'greet',
});

await pic.tearDown();
await picServer.stop();
```

***

### reinstallCode()

> **reinstallCode**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:424](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L424)

Reinstalls the given WASM module to the provided canister.
This will reset both the canister's heap and its stable memory.
To create a canister to upgrade, see [createCanister](#createcanister).
To install the initial WASM module to a new canister, see [installCode](#installcode).

#### Parameters

##### options

[`ReinstallCodeOptions`](../interfaces/ReinstallCodeOptions.md)

Options for reinstalling the code, see [ReinstallCodeOptions](../interfaces/ReinstallCodeOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { resolve } from 'node:path';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));
const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.reinstallCode({ canisterId, wasm });

await pic.tearDown();
await picServer.stop();
```

***

### resetCertifiedTime()

> **resetCertifiedTime**(): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:894](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L894)

Reset the time of the IC to the current time and immediately have query calls and
read state requests reflect the new time.

Use [resetTime](#resettime) to reset time without immediately reflecting the new time.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.resetCertifiedTime();

const time = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### resetTime()

> **resetTime**(): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:869](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L869)

Reset the time of the IC to the current time.
[tick](#tick) should be called after calling this method in order for query calls
and read state request to reflect the new time.

Use [resetCertifiedTime](#resetcertifiedtime) to set time and immediately have query calls and
read state requests reflect the new time.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.resetTime();
await pic.tick();

const time = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### setCertifiedTime()

> **setCertifiedTime**(`time`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:968](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L968)

Set the current time of the IC and immediately have query calls and
read state requests reflect the new time.

Use [setTime](#settime) to set time without immediately reflecting the new time.

#### Parameters

##### time

The time to set in milliseconds since the Unix epoch.

`number` | `Date`

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const pic = await PocketIc.create();

const date = new Date();

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.setCertifiedTime(date);
// or
await pic.setCertifiedTime(date.getTime());

const time = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### setStableMemory()

> **setStableMemory**(`canisterId`, `stableMemory`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:1290](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L1290)

Set the stable memory of a given canister.

#### Parameters

##### canisterId

`Principal`

The Principal of the canister to set the stable memory of.

##### stableMemory

`ArrayBufferLike`

A blob containing the stable memory to set.

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));
const stableMemory = new Uint8Array([0, 1, 2, 3, 4]);

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.setStableMemory(canisterId, stableMemory);

await pic.tearDown();
await picServer.stop();
```

***

### setTime()

> **setTime**(`time`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:931](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L931)

Set the current time of the IC.
[tick](#tick) should be called after calling this method in order for query calls
and read state request to reflect the new time.

Use [setCertifiedTime](#setcertifiedtime) to set time and immediately have query calls and
read state requests reflect the new time.

#### Parameters

##### time

The time to set in milliseconds since the Unix epoch.

`number` | `Date`

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const pic = await PocketIc.create();

const date = new Date();

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.setTime(date);
// or
await pic.setTime(date.getTime());

await pic.tick();

const time = await pic.getTime();

await pic.tearDown();
await picServer.stop();
```

***

### setupCanister()

> **setupCanister**\<`T`\>(`options`): `Promise`\<[`CanisterFixture`](../interfaces/CanisterFixture.md)\<`T`\>\>

Defined in: [pocket-ic.ts:149](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L149)

A convenience method that creates a new canister,
installs the given WASM module to it and returns a typesafe [Actor](../interfaces/Actor.md)
that implements the Candid interface of the canister.
To just create a canister, see [createCanister](#createcanister).
To just install code to an existing canister, see [installCode](#installcode).
To just create an Actor for an existing canister, see [createActor](#createactor).

#### Type Parameters

##### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

#### Parameters

##### options

[`SetupCanisterOptions`](../interfaces/SetupCanisterOptions.md)

Options for setting up the canister, see [SetupCanisterOptions](../interfaces/SetupCanisterOptions.md).

#### Returns

`Promise`\<[`CanisterFixture`](../interfaces/CanisterFixture.md)\<`T`\>\>

The [Actor](../interfaces/Actor.md) instance.

#### See

 - [Candid](https://internetcomputer.org/docs/current/references/candid-ref)
 - [Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const fixture = await pic.setupCanister<_SERVICE>({ idlFactory, wasmPath });
const { actor } = fixture;

await pic.tearDown();
await picServer.stop();
```

***

### startCanister()

> **startCanister**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:268](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L268)

Starts the given canister.

#### Parameters

##### options

[`StartCanisterOptions`](../interfaces/StartCanisterOptions.md)

Options for starting the canister, see [StartCanisterOptions](../interfaces/StartCanisterOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.startCanister({ canisterId });

await pic.tearDown();
await picServer.stop();
```

***

### stopCanister()

> **stopCanister**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:313](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L313)

Stops the given canister.

#### Parameters

##### options

[`StopCanisterOptions`](../interfaces/StopCanisterOptions.md)

Options for stopping the canister, see [StopCanisterOptions](../interfaces/StopCanisterOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.stopCanister({ canisterId });

await pic.tearDown();
await picServer.stop();
```

***

### tearDown()

> **tearDown**(): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:764](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L764)

Deletes the PocketIC instance.

#### Returns

`Promise`\<`void`\>

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.tearDown();
await picServer.stop();
```

***

### tick()

> **tick**(`times`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:789](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L789)

Make the IC produce and progress by one block. Accepts a parameter `times` to tick multiple times,
the default is `1`.

#### Parameters

##### times

`number` = `1`

The number of new blocks to produce and progress by. Defaults to `1`.

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.tick();

// or to tick multiple times
await pic.tick(3);

await pic.tearDown();
await picServer.stop();
```

#### Returns

`Promise`\<`void`\>

***

### updateCall()

> **updateCall**(`options`): `Promise`\<`ArrayBufferLike`\>

Defined in: [pocket-ic.ts:728](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L728)

Makes an update call to the given canister.

#### Parameters

##### options

[`UpdateCallOptions`](../interfaces/UpdateCallOptions.md)

Options for making the update call, see [UpdateCallOptions](../interfaces/UpdateCallOptions.md).

#### Returns

`Promise`\<`ArrayBufferLike`\>

The Candid-encoded response of the update call.

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

canisterId = await pic.createCanister({
  sender: controllerIdentity.getPrincipal(),
});
await pic.installCode({ canisterId, wasm });

const res = await pic.updateCall({
 canisterId,
 method: 'greet',
});

await pic.tearDown();
await picServer.stop();
```

***

### updateCanisterSettings()

> **updateCanisterSettings**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:533](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L533)

Updates the settings of the given canister.

#### Parameters

##### options

[`UpdateCanisterSettingsOptions`](../interfaces/UpdateCanisterSettingsOptions.md)

Options for updating the canister settings, see [UpdateCanisterSettingsOptions](../interfaces/UpdateCanisterSettingsOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.updateCanisterSettings({
 canisterId,
 controllers: [Principal.fromUint8Array(new Uint8Array([1]))],
});

await pic.tearDown();
await picServer.stop();
```

***

### upgradeCanister()

> **upgradeCanister**(`options`): `Promise`\<`void`\>

Defined in: [pocket-ic.ts:479](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L479)

Upgrades the given canister with the given WASM module.
This will reset the canister's heap, but preserve stable memory.
To create a canister to upgrade to, see [createCanister](#createcanister).
To install the initial WASM module to a new canister, see [installCode](#installcode).

#### Parameters

##### options

[`UpgradeCanisterOptions`](../interfaces/UpgradeCanisterOptions.md)

Options for upgrading the canister, see [UpgradeCanisterOptions](../interfaces/UpgradeCanisterOptions.md).

#### Returns

`Promise`\<`void`\>

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

#### Example

```ts
import { Principal } from '@dfinity/principal';
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { resolve } from 'node:path';

const canisterId = Principal.fromUint8Array(new Uint8Array([0]));
const wasm = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

await pic.upgradeCanister({ canisterId, wasm });

await pic.tearDown();
await picServer.stop();
```

***

### create()

> `static` **create**(`url`, `options?`): `Promise`\<`PocketIc`\>

Defined in: [pocket-ic.ts:109](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic.ts#L109)

Creates a PocketIC instance.

#### Parameters

##### url

`string`

The URL of an existing PocketIC server to connect to.

##### options?

[`CreateInstanceOptions`](../interfaces/CreateInstanceOptions.md)

Options for creating the PocketIC instance see [CreateInstanceOptions](../interfaces/CreateInstanceOptions.md).

#### Returns

`Promise`\<`PocketIc`\>

A new PocketIC instance.

#### Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const fixture = await pic.setupCanister<_SERVICE>({ idlFactory, wasmPath });
const { actor } = fixture;

await pic.tearDown();
await picServer.stop();
```

---
title: createDeferredActorClass
editUrl: false
next: true
prev: true
---

> **createDeferredActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic-deferred-actor.ts:80](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-deferred-actor.ts#L80)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

---
title: createActorClass
editUrl: false
next: true
prev: true
---

> **createActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [pocket-ic-actor.ts:90](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-actor.ts#L90)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

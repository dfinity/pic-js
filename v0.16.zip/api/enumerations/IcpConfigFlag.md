---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:247](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L247)

Flag for configuration options in `IcpConfig`.

## Enumeration Members

### Disabled

> **Disabled**: `"Disabled"`

Defined in: [pocket-ic-types.ts:248](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L248)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [pocket-ic-types.ts:249](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L249)

---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:234](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L234)

The type of state to initialize a subnet with.

## Enumeration Members

### FromPath

> **FromPath**: `"fromPath"`

Defined in: [pocket-ic-types.ts:244](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L244)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [pocket-ic-types.ts:238](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L238)

Create a new subnet with an empty state.

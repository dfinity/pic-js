---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:407](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L407)

Options for setting up a canister.

## Extends

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:424](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L424)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:468](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L468)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:463](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L463)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:497](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L497)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:478](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L478)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [pocket-ic-types.ts:411](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L411)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:473](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L473)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:483](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L483)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:430](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L430)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:514](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L514)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:508](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L508)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:418](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L418)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

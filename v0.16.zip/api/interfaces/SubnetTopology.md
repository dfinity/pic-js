---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:335](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L335)

The topology of a subnet.


### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [pocket-ic-types.ts:354](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L354)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [pocket-ic-types.ts:339](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L339)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [pocket-ic-types.ts:349](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L349)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [pocket-ic-types.ts:344](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L344)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

---
title: StopCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:551](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L551)

Options for stopping a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:555](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L555)

The Principal of the canister to stop.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:561](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L561)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:566](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L566)

The ID of the subnet that the canister resides on.

---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:879](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L879)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:898](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L898)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:893](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L893)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:888](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L888)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [pocket-ic-types.ts:883](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L883)

The type of the response, either `'success'` or `'response'`.

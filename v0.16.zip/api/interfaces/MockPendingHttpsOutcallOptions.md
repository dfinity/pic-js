---
title: MockPendingHttpsOutcallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:847](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L847)

Options for mocking a response to a pending HTTPS outcall.

## Properties

### additionalResponses?

> `optional` **additionalResponses**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)[]

Defined in: [pocket-ic-types.ts:869](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L869)

Additional responses to mock for the pending HTTPS outcall.

If non-empty, the total number of responses (one plus the number of additional responses)
must be equal to the size of the subnet on which the canister making the HTTP outcall is deployed.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:856](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L856)

The HTTPS Outcall request Id to mock a response for.

***

### response

> **response**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)

Defined in: [pocket-ic-types.ts:861](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L861)

The response to mock for the pending HTTPS outcall.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:851](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L851)

The subnet ID to that the HTTPS Outcall is being sent from.

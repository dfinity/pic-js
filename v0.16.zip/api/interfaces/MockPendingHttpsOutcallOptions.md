---
title: MockPendingHttpsOutcallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:844](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L844)

Options for mocking a response to a pending HTTPS outcall.

## Properties

### additionalResponses?

> `optional` **additionalResponses**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)[]

Defined in: [pocket-ic-types.ts:866](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L866)

Additional responses to mock for the pending HTTPS outcall.

If non-empty, the total number of responses (one plus the number of additional responses)
must be equal to the size of the subnet on which the canister making the HTTP outcall is deployed.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:853](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L853)

The HTTPS Outcall request Id to mock a response for.

***

### response

> **response**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)

Defined in: [pocket-ic-types.ts:858](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L858)

The response to mock for the pending HTTPS outcall.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:848](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L848)

The subnet ID to that the HTTPS Outcall is being sent from.

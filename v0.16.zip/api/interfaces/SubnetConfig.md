---
title: SubnetConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:83](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L83)

Common options for creating a subnet.


### T

`T` *extends* [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md) = [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md)

## Properties

### enableBenchmarkingInstructionLimits?

> `optional` **enableBenchmarkingInstructionLimits**: `boolean`

Defined in: [pocket-ic-types.ts:98](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L98)

Whether to enable benchmarking instruction limits.
Defaults to `false`.

***

### enableDeterministicTimeSlicing?

> `optional` **enableDeterministicTimeSlicing**: `boolean`

Defined in: [pocket-ic-types.ts:92](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L92)

Whether to enable deterministic time slicing.
Defaults to `true`.

***

### state

> **state**: `T`

Defined in: [pocket-ic-types.ts:103](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L103)

The state configuration for the subnet.

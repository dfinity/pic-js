---
title: InstallCodeOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:575](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L575)

Options for installing a WASM module to a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:592](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L592)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:579](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L579)

The Principal of the canister to install the code to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:598](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L598)

The principal to install the code as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:603](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L603)

The ID of the subnet that the canister resides on.

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:586](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L586)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

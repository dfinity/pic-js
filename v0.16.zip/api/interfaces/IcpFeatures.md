---
title: IcpFeatures
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:294](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L294)

Specifies ICP features enabled by deploying their corresponding system canisters
when creating a PocketIC instance and keeping them up to date during the PocketIC instance lifetime.
The subnets to which the corresponding system canisters are deployed must be empty.
An ICP feature is enabled if its `IcpFeaturesConfig` is provided, i.e., if the corresponding field is set.

## Properties

### cyclesMinting?

> `optional` **cyclesMinting**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:306](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L306)

Deploys the NNS cycles minting canister, sets ICP/XDR conversion rate, and keeps its subnet lists in sync with PocketIC topology.
If enabled, the default timestamp of a PocketIC instance is set to 10 May 2021 10:00:01 AM CEST
(the smallest value that is strictly larger than the default timestamp hard-coded in the CMC state).

***

### cyclesToken?

> `optional` **cyclesToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:314](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L314)

Deploys the cycles ledger and index canisters.

***

### icpToken?

> `optional` **icpToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:310](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L310)

Deploys the ICP ledger and index canisters and initializes the ICP account of the anonymous principal with 1,000,000,000 ICP.

***

### ii?

> `optional` **ii**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:328](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L328)

Deploys the Internet Identity canister.

***

### nnsGovernance?

> `optional` **nnsGovernance**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:319](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L319)

Deploys the NNS governance and root canisters and sets up an initial NNS neuron with 1 ICP stake.
The initial NNS neuron is controlled by the principal `hpikg-6exdt-jn33w-ndty3-fc7jc-tl2lr-buih3-cs3y7-tftkp-sfp62-gqe`.

***

### nnsUi?

> `optional` **nnsUi**: `undefined`

Defined in: [pocket-ic-types.ts:332](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L332)

Currently not supported.

***

### registry?

> `optional` **registry**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:300](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L300)

Deploys the NNS registry canister and keeps its content in sync with registry used internally by PocketIC.
Note. The registry used internally by PocketIC is not updated after changing the registry stored in the registry canister
(e.g., after executing an NNS proposal mutating the registry).

***

### sns?

> `optional` **sns**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [pocket-ic-types.ts:324](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L324)

Deploys the SNS-W and aggregator canisters, sets up the SNS subnet list in the SNS-W canister according to PocketIC topology,
and uploads the SNS canister WASMs to the SNS-W canister.

---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:898](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L898)

## Properties

### message

> **message**: `string`

Defined in: [pocket-ic-types.ts:912](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L912)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:907](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L907)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [pocket-ic-types.ts:902](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L902)

The type of the response, either `'reject'` or `'response'`.

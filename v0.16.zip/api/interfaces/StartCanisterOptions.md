---
title: StartCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:527](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L527)

Options for starting a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:531](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L531)

The Principal of the canister to start.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:537](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L537)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:542](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L542)

The ID of the subnet that the canister resides on.

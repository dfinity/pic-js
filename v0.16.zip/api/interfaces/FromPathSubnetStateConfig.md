---
title: FromPathSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:203](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L203)

Options for creating a subnet from an existing state on the filesystem.


### path

> **path**: `string`

Defined in: [pocket-ic-types.ts:225](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L225)

The path to the subnet state.

This directory should have the following structure:
```text
  |-- backups/
  |-- checkpoints/
  |-- diverged_checkpoints/
  |-- diverged_state_markers/
  |-- fs_tmp/
  |-- page_deltas/
  |-- tip/
  |-- tmp/
  |-- states_metadata.pbuf
```

***

### type

> **type**: [`FromPath`](../enumerations/SubnetStateType.md#frompath)

Defined in: [pocket-ic-types.ts:207](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L207)

The type of subnet state to initialize the subnet with.

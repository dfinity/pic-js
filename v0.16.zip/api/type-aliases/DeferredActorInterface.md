---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-deferred-actor.ts#L15)


### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

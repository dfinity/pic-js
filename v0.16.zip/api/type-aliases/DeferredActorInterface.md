---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-deferred-actor.ts#L15)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

---
title: BitcoinSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:156](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L156)

Options for a Bitcoin subnet's state.

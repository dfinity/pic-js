---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:134](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L134)

Options for creating an II subnet.

---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [pocket-ic-types.ts:875](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L875)

An HTTPS Outcall response mock.

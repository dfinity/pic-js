---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [pocket-ic-types.ts:872](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L872)

An HTTPS Outcall response mock.

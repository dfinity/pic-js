---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [pocket-ic-types.ts:839](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L839)

An HTTP header for an HTTPS outcall.

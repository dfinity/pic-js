---
title: NnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`NnsSubnetStateConfig`](NnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:109](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L109)

Options for creating an NNS subnet.

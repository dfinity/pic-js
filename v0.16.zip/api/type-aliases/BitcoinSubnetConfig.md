---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:151](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L151)

Options for creating a Bitcoin subnet.

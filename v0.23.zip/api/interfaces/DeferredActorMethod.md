---
title: DeferredActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-deferred-actor.ts:8](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-deferred-actor.ts#L8)

## Type Parameters

### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **DeferredActorMethod**(...`args`): `Promise`\<() => `Promise`\<`Ret`\>\>

Defined in: [packages/pic/src/pocket-ic-deferred-actor.ts:12](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-deferred-actor.ts#L12)

## Parameters

### args

...`Args`

## Returns

`Promise`\<() => `Promise`\<`Ret`\>\>

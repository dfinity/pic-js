---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:854](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L854)

The result of querying the status of a canister.
This is a subset of the IC management canister `canister_status` response.
Some fields (e.g. `snapshotVisibility`, `logMemoryLimit`, `memoryMetrics`)
are not yet included because the PocketIC server does not return them.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:888](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L888)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:898](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L898)

The amount of cycles burned per day when idle.

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:883](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L883)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:878](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L878)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:903](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L903)

Query call statistics for the canister.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:893](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L893)

The reserved cycles of the canister.

***

### settings

> **settings**: `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:863](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L863)

The definite settings of the canister.

#### computeAllocation

> **computeAllocation**: `bigint`

#### controllers

> **controllers**: `Principal`[]

#### environmentVariables

> **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

#### freezingThreshold

> **freezingThreshold**: `bigint`

#### logVisibility

> **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

#### memoryAllocation

> **memoryAllocation**: `bigint`

#### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

#### wasmMemoryLimit

> **wasmMemoryLimit**: `bigint`

#### wasmMemoryThreshold

> **wasmMemoryThreshold**: `bigint`

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:858](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L858)

The current status of the canister.

---
title: CanisterQueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:838](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L838)

Query statistics for a canister.

## Properties

### numCallsTotal

> **numCallsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:839](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L839)

***

### numInstructionsTotal

> **numInstructionsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:840](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L840)

***

### requestPayloadBytesTotal

> **requestPayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:841](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L841)

***

### responsePayloadBytesTotal

> **responsePayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:842](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L842)

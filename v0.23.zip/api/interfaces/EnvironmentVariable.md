---
title: EnvironmentVariable
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:504](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L504)

Environment variable for canister settings.

## Properties

### name

> **name**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:505](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L505)

***

### value

> **value**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:506](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L506)

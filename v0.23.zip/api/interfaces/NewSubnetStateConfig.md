---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:240](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L240)

Options for creating a new subnet an empty state.

## Properties

### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [packages/pic/src/pocket-ic-types.ts:244](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L244)

The type of subnet state to initialize the subnet with.

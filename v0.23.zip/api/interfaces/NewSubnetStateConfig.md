---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:240](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L240)

Options for creating a new subnet an empty state.

## Properties

### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [packages/pic/src/pocket-ic-types.ts:244](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L244)

The type of subnet state to initialize the subnet with.

---
title: CreateInstanceOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:14](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L14)

Options for creating a PocketIc instance.

## Properties

### application?

> `optional` **application**: [`ApplicationSubnetConfig`](../type-aliases/ApplicationSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:57](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L57)

Configuration options for creating application subnets.
An application subnet will be created for each configuration object provided.
If no config objects are provided, no application subnets are setup.

***

### bitcoin?

> `optional` **bitcoin**: [`BitcoinSubnetConfig`](../type-aliases/BitcoinSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:43](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L43)

Configuration options for creating a Bitcoin subnet.
If no config is provided, the Bitcoin subnet is not setup.

***

### disableIngressValidation?

> `optional` **disableIngressValidation**: `boolean`

Defined in: [packages/pic/src/pocket-ic-types.ts:99](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L99)

Disables ingress message validation on the PocketIC instance.

When enabled, the PocketIC server skips the validation that would normally
reject malformed or otherwise invalid ingress messages. This is useful for
testing canister behavior against ingress messages that the replica would
ordinarily refuse to process.

Defaults to `false`.

***

### fiduciary?

> `optional` **fiduciary**: [`FiduciarySubnetConfig`](../type-aliases/FiduciarySubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:37](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L37)

Configuration options for creating a Fiduciary subnet.
If no config is provided, the Fiduciary subnet is not setup.

***

### icpConfig?

> `optional` **icpConfig**: [`IcpConfig`](IcpConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:82](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L82)

Determines what non-mainnet features should be
enabled for the PocketIC instance.

***

### icpFeatures?

> `optional` **icpFeatures**: [`IcpFeatures`](IcpFeatures.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:87](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L87)

Determines what ICP features should be enabled for the PocketIC instance.

***

### ii?

> `optional` **ii**: [`IiSubnetConfig`](../type-aliases/IiSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:31](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L31)

Configuration options for creating an II subnet.
If no config is provided, the II subnet is not setup.

***

### ~~ingressMaxRetries?~~

> `optional` **ingressMaxRetries**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:77](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L77)

#### Deprecated

This option is no longer used. The PocketIC server now handles
ingress message processing internally via the `await_ingress_message` endpoint.
Use [CreateInstanceOptions.processingTimeoutMs](#processingtimeoutms) to control how long update
calls can wait for ingress processing to complete.

***

### nns?

> `optional` **nns**: [`NnsSubnetConfig`](../type-aliases/NnsSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:19](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L19)

Configuration options for creating an NNS subnet.
If no config is provided, the NNS subnet is not setup.

***

### processingTimeoutMs?

> `optional` **processingTimeoutMs**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:69](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L69)

How long the PocketIC client should wait for a response from the server.

***

### sns?

> `optional` **sns**: [`SnsSubnetConfig`](../type-aliases/SnsSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:25](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L25)

Configuration options for creating an SNS subnet.
If no config is provided, the SNS subnet is not setup.

***

### system?

> `optional` **system**: [`SystemSubnetConfig`](../type-aliases/SystemSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:50](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L50)

Configuration options for creating system subnets.
A system subnet will be created for each configuration object provided.
If no config objects are provided, no system subnets are setup.

***

### verifiedApplication?

> `optional` **verifiedApplication**: [`VerifiedApplicationSubnetConfig`](../type-aliases/VerifiedApplicationSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:64](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L64)

Configuration options for creating verified application subnets.
A verified application subnet will be created for each configuration object provided.
If no config objects are provided, no verified application subnets are setup.

---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1120](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1120)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1139](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1139)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:1134](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1134)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1129](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1129)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1124](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1124)

The type of the response, either `'success'` or `'response'`.

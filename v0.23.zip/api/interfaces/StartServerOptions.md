---
title: StartServerOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-server-types.ts:4](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-server-types.ts#L4)

Options for starting a PocketIC server.

## Properties

### binPath?

> `optional` **binPath**: `string`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:20](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-server-types.ts#L20)

Path to the PocketIC server binary.
Defaults to the `POCKET_IC_BIN` environment variable if set,
otherwise the binary downloaded by this package's install script.

***

### showCanisterLogs?

> `optional` **showCanisterLogs**: `boolean`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:13](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-server-types.ts#L13)

Whether to pipe the canister logs to the parent process's stderr.

***

### showRuntimeLogs?

> `optional` **showRuntimeLogs**: `boolean`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:8](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-server-types.ts#L8)

Whether to pipe the runtimes's logs to the parent process's stdout.

***

### ttl?

> `optional` **ttl**: `number`

Defined in: [packages/pic/src/pocket-ic-server-types.ts:28](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-server-types.ts#L28)

Time to live of the server in seconds since the last completed operation,
after which the server shuts down gracefully.
Must be a non-negative integer.
If not provided, the server's default time to live is used.

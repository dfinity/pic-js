---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1157](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1157)

## Properties

### message

> **message**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1171](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1171)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1166](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1166)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1161](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1161)

The type of the response, either `'reject'` or `'response'`.

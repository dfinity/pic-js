---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1142](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1142)

## Properties

### message

> **message**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1156](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1156)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1151](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1151)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1146](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1146)

The type of the response, either `'reject'` or `'response'`.

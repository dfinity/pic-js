---
title: SenderInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:921](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L921)

Sender information attached to a canister call.

This is passed through to the canister, which can inspect it via the
`msg_caller_info_data` and `msg_caller_info_signer` system APIs. PocketIC
does not validate or verify anything; it simply forwards both fields for
canister inspection, mocking the signer's signature.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### info

> **info**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:925](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L925)

An arbitrary binary blob of sender information.

***

### signer

> **signer**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:930](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L930)

The Principal of the canister whose signature will be mocked.

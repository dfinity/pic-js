---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1063](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1063)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### DELETE

> **DELETE**: `"DELETE"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1087](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1087)

A DELETE request.

***

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1067](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1067)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1077](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1077)

A HEAD request.

***

### PATCH

> **PATCH**: `"PATCH"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1092](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1092)

A PATCH request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1072](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1072)

A POST request.

***

### PUT

> **PUT**: `"PUT"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1082](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L1082)

A PUT request.

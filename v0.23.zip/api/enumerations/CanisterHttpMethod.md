---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1063](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1063)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1067](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1067)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1077](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1077)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1072](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1072)

A POST request.

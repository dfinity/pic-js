---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:294](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L294)

Flag for configuration options in `IcpConfig`.

## Enumeration Members

### Disabled

> **Disabled**: `"Disabled"`

Defined in: [packages/pic/src/pocket-ic-types.ts:295](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L295)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [packages/pic/src/pocket-ic-types.ts:296](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L296)

---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:235](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L235)

Options for a verified application subnet's state.

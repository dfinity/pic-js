---
title: VerifiedApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`VerifiedApplicationSubnetStateConfig`](VerifiedApplicationSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:229](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L229)

Options for creating a verified application subnet.

---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\> & `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:209](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L209)

Options for creating an application subnet.

## Type Declaration

### costSchedule?

> `optional` **costSchedule**: [`CanisterCyclesCostSchedule`](../enumerations/CanisterCyclesCostSchedule.md)

The canister cycles cost schedule for the subnet.
Defaults to [CanisterCyclesCostSchedule.Normal](../enumerations/CanisterCyclesCostSchedule.md#normal).

Only supported on application subnets. The PocketIC server will reject
non-default values on other subnet kinds.

---
title: SnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:164](https://github.com/dfinity/pic-js/blob/a3087b5efe09d861d6451b9fed1f0c64e13aad6a/packages/pic/src/pocket-ic-types.ts#L164)

Options for an SNS subnet's state.

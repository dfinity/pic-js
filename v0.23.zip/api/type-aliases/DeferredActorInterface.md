---
title: DeferredActorInterface
editUrl: false
next: true
prev: true
---

> **DeferredActorInterface**\<`T`\> = `{ [K in keyof T]: DeferredActorMethod<Parameters<T[K]>, ReturnType<T[K]>> }`

Defined in: [packages/pic/src/pocket-ic-deferred-actor.ts:15](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-deferred-actor.ts#L15)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

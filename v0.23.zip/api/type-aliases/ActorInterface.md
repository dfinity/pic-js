---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [packages/pic/src/pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.

## Type Parameters

### T

`T` = `object`

---
title: SnapshotVisibility
editUrl: false
next: true
prev: true
---

> **SnapshotVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:526](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L526)

Snapshot visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

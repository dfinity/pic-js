---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

> **CanisterStatus** = \{ `running`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `stopped`: `null`; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:828](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L828)

The status of a canister.

---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1116](https://github.com/dfinity/pic-js/blob/33361ad66a016e0de6ca2ce60597d3afa2814397/packages/pic/src/pocket-ic-types.ts#L1116)

An HTTPS Outcall response mock.

---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [pocket-ic-types.ts:846](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L846)

An HTTP header for an HTTPS outcall.

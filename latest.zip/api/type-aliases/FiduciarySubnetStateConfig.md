---
title: FiduciarySubnetStateConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:140](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L140)

Options for a Fiduciary subnet's state.

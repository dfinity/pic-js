---
title: FiduciarySubnetStateConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:146](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L146)

Options for a Fiduciary subnet's state.

---
title: FiduciarySubnetStateConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:146](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L146)

Options for a Fiduciary subnet's state.

---
title: FiduciarySubnetStateConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:145](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L145)

Options for a Fiduciary subnet's state.

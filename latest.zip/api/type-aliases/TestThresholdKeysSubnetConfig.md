---
title: TestThresholdKeysSubnetConfig
editUrl: false
next: true
prev: true
---

> **TestThresholdKeysSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`TestThresholdKeysSubnetStateConfig`](TestThresholdKeysSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:240](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L240)

Options for creating a test threshold keys subnet.

---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:169](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L169)

Options for creating an II subnet.

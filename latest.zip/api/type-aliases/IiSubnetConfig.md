---
title: IiSubnetConfig
editUrl: false
next: true
prev: true
---

> **IiSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`IiSubnetStateConfig`](IiSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:134](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L134)

Options for creating an II subnet.

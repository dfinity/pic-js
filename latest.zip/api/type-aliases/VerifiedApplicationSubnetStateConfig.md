---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:188](https://github.com/dfinity/pic-js/blob/36abcf907b5cff4ee4faa25fb1868801c395909e/packages/pic/src/pocket-ic-types.ts#L188)

Options for a verified application subnet's state.

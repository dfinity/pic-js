---
title: VerifiedApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`VerifiedApplicationSubnetStateConfig`](VerifiedApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:185](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L185)

Options for creating a verified application subnet.

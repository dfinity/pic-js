---
title: VerifiedApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`VerifiedApplicationSubnetStateConfig`](VerifiedApplicationSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:229](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L229)

Options for creating a verified application subnet.

---
title: SnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:129](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L129)

Options for an SNS subnet's state.

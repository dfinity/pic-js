---
title: SnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:126](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L126)

Options for an SNS subnet's state.

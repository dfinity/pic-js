---
title: SnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:129](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L129)

Options for an SNS subnet's state.

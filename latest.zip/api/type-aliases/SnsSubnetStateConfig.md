---
title: SnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:215](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L215)

Options for an SNS subnet's state.

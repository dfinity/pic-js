---
title: CanisterLogFilter
editUrl: false
next: true
prev: true
---

> **CanisterLogFilter** = [`CanisterLogIdxFilter`](../interfaces/CanisterLogIdxFilter.md) \| [`CanisterLogTimestampFilter`](../interfaces/CanisterLogTimestampFilter.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1295](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1295)

A range of canister log records to fetch, see [FetchCanisterLogsOptions.filter](../interfaces/FetchCanisterLogsOptions.md#filter).

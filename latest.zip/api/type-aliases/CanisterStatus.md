---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

> **CanisterStatus** = \{ `running`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `stopped`: `null`; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:828](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L828)

The status of a canister.

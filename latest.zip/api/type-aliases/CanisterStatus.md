---
title: CanisterStatus
editUrl: false
next: true
prev: true
---

> **CanisterStatus** = \{ `running`: `null`; \} \| \{ `stopping`: `null`; \} \| \{ `stopped`: `null`; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:725](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L725)

The status of a canister.

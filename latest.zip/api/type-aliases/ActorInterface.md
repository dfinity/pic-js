---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.

## Type Parameters

### T

`T` = `object`

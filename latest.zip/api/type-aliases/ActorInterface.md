---
title: ActorInterface
editUrl: false
next: true
prev: true
---

> **ActorInterface**\<`T`\> = `{ [K in keyof T]: ActorMethod }`

Defined in: [pocket-ic-actor.ts:21](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-actor.ts#L21)

Candid interface of a canister.

## Type Parameters

### T

`T` = `object`

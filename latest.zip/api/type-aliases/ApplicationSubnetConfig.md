---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\> & `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:209](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L209)

Options for creating an application subnet.

## Type Declaration

### costSchedule?

> `optional` **costSchedule**: [`CanisterCyclesCostSchedule`](../enumerations/CanisterCyclesCostSchedule.md)

The canister cycles cost schedule for the subnet.
Defaults to [CanisterCyclesCostSchedule.Normal](../enumerations/CanisterCyclesCostSchedule.md#normal).

Only supported on application subnets. The PocketIC server will reject
non-default values on other subnet kinds.

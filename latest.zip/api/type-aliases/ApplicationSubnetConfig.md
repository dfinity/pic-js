---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:165](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L165)

Options for creating an application subnet.

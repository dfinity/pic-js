---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:174](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L174)

Options for creating an application subnet.

---
title: ApplicationSubnetConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`ApplicationSubnetStateConfig`](ApplicationSubnetStateConfig.md)\> & `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:271](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L271)

Options for creating an application subnet.

## Type Declaration

### costSchedule?

> `optional` **costSchedule**: [`CanisterCyclesCostSchedule`](../enumerations/CanisterCyclesCostSchedule.md)

The canister cycles cost schedule for the subnet.
Defaults to [CanisterCyclesCostSchedule.Normal](../enumerations/CanisterCyclesCostSchedule.md#normal).

Only supported on application subnets. The PocketIC server will reject
non-default values on other subnet kinds.

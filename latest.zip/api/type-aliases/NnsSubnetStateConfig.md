---
title: NnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](../interfaces/FromPathSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:117](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L117)

Options for an NNS subnet's state.

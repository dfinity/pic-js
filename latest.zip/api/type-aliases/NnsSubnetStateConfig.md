---
title: NnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](../interfaces/FromPathSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:108](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L108)

Options for an NNS subnet's state.

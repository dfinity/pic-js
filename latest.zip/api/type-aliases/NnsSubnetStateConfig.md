---
title: NnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](../interfaces/FromPathSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:121](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L121)

Options for an NNS subnet's state.

---
title: NnsSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](../interfaces/FromPathSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:117](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L117)

Options for an NNS subnet's state.

---
title: ApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **ApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:180](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L180)

Options for an application subnet's state.

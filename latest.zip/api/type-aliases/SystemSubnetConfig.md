---
title: SystemSubnetConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SystemSubnetStateConfig`](SystemSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:261](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L261)

Options for creating a system subnet.

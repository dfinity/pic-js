---
title: SystemSubnetConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SystemSubnetStateConfig`](SystemSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:168](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L168)

Options for creating a system subnet.

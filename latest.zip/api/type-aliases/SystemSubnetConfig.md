---
title: SystemSubnetConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SystemSubnetStateConfig`](SystemSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:155](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L155)

Options for creating a system subnet.

---
title: LogVisibility
editUrl: false
next: true
prev: true
---

> **LogVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:614](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L614)

Log visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

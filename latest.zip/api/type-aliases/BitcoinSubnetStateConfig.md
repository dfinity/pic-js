---
title: BitcoinSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:159](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L159)

Options for a Bitcoin subnet's state.

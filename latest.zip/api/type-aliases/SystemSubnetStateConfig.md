---
title: SystemSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:204](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L204)

Options for a system subnet's state.

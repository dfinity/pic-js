---
title: SnapshotVisibility
editUrl: false
next: true
prev: true
---

> **SnapshotVisibility** = \{ `controllers`: `null`; \} \| \{ `public`: `null`; \} \| \{ `allowedViewers`: `Principal`[]; \}

Defined in: [packages/pic/src/pocket-ic-types.ts:526](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L526)

Snapshot visibility for canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

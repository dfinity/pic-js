---
title: TestThresholdKeysSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **TestThresholdKeysSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:246](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L246)

Options for a test threshold keys subnet's state.

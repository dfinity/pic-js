---
title: DeferredActor
editUrl: false
next: true
prev: true
---

> **DeferredActor**\<`T`\> = [`DeferredActorInterface`](DeferredActorInterface.md)\<`T`\> & `object`

Defined in: [packages/pic/src/pocket-ic-deferred-actor.ts:21](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-deferred-actor.ts#L21)

## Type Declaration

### setIdentity()

> **setIdentity**(`identity`): `void`

Set a Principal to be used as sender for all calls to the canister.
This is a convenience method over setPrincipal that accepts an
Identity and internally extracts the Principal.

#### Parameters

##### identity

`Identity`

The identity to set.

#### Returns

`void`

#### See

 - [Identity](https://js.icp.build/core/latest/libs/agent/api/#identity-9)
 - [Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

#### Example

```ts
import { PocketIc } from '@dfinity/pic';
import { AnonymousIdentity } from '@icp-sdk/core/agent';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const pic = await PocketIc.create();
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

actor.setIdentity(new AnonymousIdentity());
```

### setPrincipal()

> **setPrincipal**(`principal`): `void`

Set a Principal to be used as sender for all calls to the canister.

#### Parameters

##### principal

`Principal`

The Principal to set.

#### Returns

`void`

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

#### Example

```ts
import { PocketIc } from '@dfinity/pic';
import { Principal } from '@icp-sdk/core/principal';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const pic = await PocketIc.create();
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

actor.setPrincipal(Principal.anonymous());
```

## Type Parameters

### T

`T` *extends* [`ActorInterface`](ActorInterface.md)\<`T`\> = [`ActorInterface`](ActorInterface.md)

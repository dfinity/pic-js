---
title: FiduciarySubnetConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`FiduciarySubnetStateConfig`](FiduciarySubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:141](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L141)

Options for creating a Fiduciary subnet.

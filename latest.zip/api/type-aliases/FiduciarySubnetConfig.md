---
title: FiduciarySubnetConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`FiduciarySubnetStateConfig`](FiduciarySubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:148](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L148)

Options for creating a Fiduciary subnet.

---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:145](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L145)

Options for creating a Bitcoin subnet.

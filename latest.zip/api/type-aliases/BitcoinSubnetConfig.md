---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [packages/pic/src/pocket-ic-types.ts:189](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L189)

Options for creating a Bitcoin subnet.

---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:150](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L150)

Options for creating a Bitcoin subnet.

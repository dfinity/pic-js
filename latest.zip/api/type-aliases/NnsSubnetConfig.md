---
title: NnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`NnsSubnetStateConfig`](NnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:112](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L112)

Options for creating an NNS subnet.

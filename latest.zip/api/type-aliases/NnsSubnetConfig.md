---
title: NnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`NnsSubnetStateConfig`](NnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:103](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L103)

Options for creating an NNS subnet.

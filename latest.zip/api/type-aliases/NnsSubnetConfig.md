---
title: NnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **NnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`NnsSubnetStateConfig`](NnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:108](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L108)

Options for creating an NNS subnet.

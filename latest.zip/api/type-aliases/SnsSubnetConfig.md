---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:124](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L124)

Options for creating an SNS subnet.

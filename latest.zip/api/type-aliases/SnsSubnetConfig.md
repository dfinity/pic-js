---
title: SnsSubnetConfig
editUrl: false
next: true
prev: true
---

> **SnsSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SnsSubnetStateConfig`](SnsSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:121](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L121)

Options for creating an SNS subnet.

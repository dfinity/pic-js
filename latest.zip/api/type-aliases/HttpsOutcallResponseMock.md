---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [pocket-ic-types.ts:872](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L872)

An HTTPS Outcall response mock.

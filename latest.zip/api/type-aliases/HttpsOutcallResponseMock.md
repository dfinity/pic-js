---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:974](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L974)

An HTTPS Outcall response mock.

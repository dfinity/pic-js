---
title: HttpsOutcallResponseMock
editUrl: false
next: true
prev: true
---

> **HttpsOutcallResponseMock** = [`HttpsOutcallSuccessResponse`](../interfaces/HttpsOutcallSuccessResponse.md) \| [`HttpsOutcallRejectResponse`](../interfaces/HttpsOutcallRejectResponse.md)

Defined in: [pocket-ic-types.ts:804](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L804)

An HTTPS Outcall response mock.

---
title: createActorClass
editUrl: false
next: true
prev: true
---

> **createActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [packages/pic/src/pocket-ic-actor.ts:90](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-actor.ts#L90)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

---
title: createActorClass
editUrl: false
next: true
prev: true
---

> **createActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`Actor`](../interfaces/Actor.md)\<`T`\>

Defined in: [packages/pic/src/pocket-ic-actor.ts:90](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-actor.ts#L90)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`Actor`](../interfaces/Actor.md)\<`T`\>

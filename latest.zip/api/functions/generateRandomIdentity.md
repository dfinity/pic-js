---
title: generateRandomIdentity
editUrl: false
next: true
prev: true
---

> **generateRandomIdentity**(): `Identity`

Defined in: [identity.ts:92](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/identity.ts#L92)

Create an Identity from a randomly generated bip39 seed phrase.
Subsequent calls to this function will produce different Identities
with an extremely low probability of collision.

This is useful for tests where it is important to avoid conflicts arising
from multiple identities accessing the same canister and maintaining
the necessary seed phrases would become cumbersome.

## Returns

`Identity`

An identity created from a random seed phrase.

## See

[Identity](https://js.icp.build/core/latest/libs/agent/api/interfaces/identity/)

## Example

```ts
import { PocketIc, PocketIcServer, generateRandomIdentity } from '@dfinity/pic';
import { AnonymousIdentity } from '@dfinity/agent';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

const bob = generateRandomIdentity();
actor.setIdentity(bob);

await pic.tearDown();
await picServer.stop();
```

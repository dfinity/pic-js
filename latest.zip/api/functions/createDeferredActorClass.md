---
title: createDeferredActorClass
editUrl: false
next: true
prev: true
---

> **createDeferredActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic-deferred-actor.ts:80](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-deferred-actor.ts#L80)


### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

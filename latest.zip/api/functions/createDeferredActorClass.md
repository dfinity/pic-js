---
title: createDeferredActorClass
editUrl: false
next: true
prev: true
---

> **createDeferredActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic-deferred-actor.ts:80](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-deferred-actor.ts#L80)


### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

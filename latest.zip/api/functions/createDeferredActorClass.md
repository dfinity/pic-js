---
title: createDeferredActorClass
editUrl: false
next: true
prev: true
---

> **createDeferredActorClass**\<`T`\>(`interfaceFactory`, `canisterId`, `pocketIcClient`): [`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

Defined in: [pocket-ic-deferred-actor.ts:80](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-deferred-actor.ts#L80)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = `object`

## Parameters

### interfaceFactory

`InterfaceFactory`

### canisterId

`Principal`

### pocketIcClient

`PocketIcClient`

## Returns

[`DeferredActor`](../type-aliases/DeferredActor.md)\<`T`\>

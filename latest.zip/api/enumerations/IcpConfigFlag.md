---
title: IcpConfigFlag
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:247](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L247)

Flag for configuration options in `IcpConfig`.


### Disabled

> **Disabled**: `"Disabled"`

Defined in: [pocket-ic-types.ts:248](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L248)

***

### Enabled

> **Enabled**: `"Enabled"`

Defined in: [pocket-ic-types.ts:249](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L249)

---
title: IcpFeaturesConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:278](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L278)

Configuration options in `IcpFeatures`.


### DefaultConfig

> **DefaultConfig**: `"DefaultConfig"`

Defined in: [pocket-ic-types.ts:282](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L282)

Default configuration of an ICP feature resembling mainnet configuration as closely as possible.

---
title: IcpFeaturesConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:281](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L281)

Configuration options in `IcpFeatures`.

## Enumeration Members

### DefaultConfig

> **DefaultConfig**: `"DefaultConfig"`

Defined in: [pocket-ic-types.ts:285](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L285)

Default configuration of an ICP feature resembling mainnet configuration as closely as possible.

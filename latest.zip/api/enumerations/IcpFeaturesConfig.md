---
title: IcpFeaturesConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:281](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L281)

Configuration options in `IcpFeatures`.

## Enumeration Members

### DefaultConfig

> **DefaultConfig**: `"DefaultConfig"`

Defined in: [pocket-ic-types.ts:285](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/pocket-ic-types.ts#L285)

Default configuration of an ICP feature resembling mainnet configuration as closely as possible.

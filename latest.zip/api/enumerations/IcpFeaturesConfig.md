---
title: IcpFeaturesConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:277](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L277)

Configuration options in `IcpFeatures`.


### DefaultConfig

> **DefaultConfig**: `"DefaultConfig"`

Defined in: [pocket-ic-types.ts:281](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L281)

Default configuration of an ICP feature resembling mainnet configuration as closely as possible.

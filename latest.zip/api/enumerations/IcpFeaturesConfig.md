---
title: IcpFeaturesConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:285](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L285)

Configuration options in `IcpFeatures`.

## Enumeration Members

### DefaultConfig

> **DefaultConfig**: `"DefaultConfig"`

Defined in: [pocket-ic-types.ts:289](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L289)

Default configuration of an ICP feature resembling mainnet configuration as closely as possible.

---
title: CanisterCyclesCostSchedule
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:132](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L132)

The canister cycles cost schedule for a subnet.
See the `SubnetSpec.cost_schedule` field in the PocketIC server.

## Enumeration Members

### Free

> **Free**: `"Free"`

Defined in: [packages/pic/src/pocket-ic-types.ts:141](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L141)

Canisters are not charged cycles. Only supported on application subnets.

***

### Normal

> **Normal**: `"Normal"`

Defined in: [packages/pic/src/pocket-ic-types.ts:136](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L136)

Canisters are charged cycles as on the ICP mainnet.

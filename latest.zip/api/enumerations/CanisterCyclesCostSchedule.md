---
title: CanisterCyclesCostSchedule
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:183](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L183)

The canister cycles cost schedule for a subnet.
See the `SubnetSpec.cost_schedule` field in the PocketIC server.

## Enumeration Members

### Free

> **Free**: `"Free"`

Defined in: [packages/pic/src/pocket-ic-types.ts:192](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L192)

Canisters are not charged cycles. Only supported on application subnets.

***

### Normal

> **Normal**: `"Normal"`

Defined in: [packages/pic/src/pocket-ic-types.ts:187](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L187)

Canisters are charged cycles as on the ICP mainnet.

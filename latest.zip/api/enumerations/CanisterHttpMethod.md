---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:921](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L921)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:925](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L925)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:935](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L935)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:930](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L930)

A POST request.

---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1063](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L1063)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1067](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L1067)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1077](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L1077)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1072](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L1072)

A POST request.

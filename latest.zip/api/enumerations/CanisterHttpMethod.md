---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:819](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L819)

The HTTP method used for an HTTPS outcall.


### GET

> **GET**: `"GET"`

Defined in: [pocket-ic-types.ts:823](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L823)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [pocket-ic-types.ts:833](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L833)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [pocket-ic-types.ts:828](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L828)

A POST request.

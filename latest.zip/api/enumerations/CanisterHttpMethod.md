---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:751](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L751)

The HTTP method used for an HTTPS outcall.


### GET

> **GET**: `"GET"`

Defined in: [pocket-ic-types.ts:755](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L755)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [pocket-ic-types.ts:765](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L765)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [pocket-ic-types.ts:760](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L760)

A POST request.

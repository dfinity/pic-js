---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:826](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L826)

The HTTP method used for an HTTPS outcall.

## Enumeration Members

### GET

> **GET**: `"GET"`

Defined in: [pocket-ic-types.ts:830](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L830)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [pocket-ic-types.ts:840](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L840)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [pocket-ic-types.ts:835](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L835)

A POST request.

---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:813](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L813)

The HTTP method used for an HTTPS outcall.


### GET

> **GET**: `"GET"`

Defined in: [pocket-ic-types.ts:817](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L817)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [pocket-ic-types.ts:827](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L827)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [pocket-ic-types.ts:822](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L822)

A POST request.

---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:225](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L225)

The type of state to initialize a subnet with.


### FromPath

> **FromPath**: `"fromPath"`

Defined in: [pocket-ic-types.ts:235](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L235)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [pocket-ic-types.ts:229](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L229)

Create a new subnet with an empty state.

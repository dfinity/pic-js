---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:231](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L231)

The type of state to initialize a subnet with.


### FromPath

> **FromPath**: `"fromPath"`

Defined in: [pocket-ic-types.ts:241](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L241)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [pocket-ic-types.ts:235](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L235)

Create a new subnet with an empty state.

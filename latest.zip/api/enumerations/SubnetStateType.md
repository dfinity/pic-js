---
title: SubnetStateType
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:238](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L238)

The type of state to initialize a subnet with.

## Enumeration Members

### FromPath

> **FromPath**: `"fromPath"`

Defined in: [packages/pic/src/pocket-ic-types.ts:248](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L248)

Load existing subnet state from the given path.
The path must be on a filesystem accessible by the PocketIC server.

***

### New

> **New**: `"new"`

Defined in: [packages/pic/src/pocket-ic-types.ts:242](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L242)

Create a new subnet with an empty state.

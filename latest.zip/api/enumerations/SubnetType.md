---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:363](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L363)

The type of a subnet.


### Application

> **Application**: `"Application"`

Defined in: [pocket-ic-types.ts:367](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L367)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [pocket-ic-types.ts:372](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L372)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [pocket-ic-types.ts:377](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L377)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [pocket-ic-types.ts:382](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L382)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [pocket-ic-types.ts:387](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L387)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [pocket-ic-types.ts:392](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L392)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [pocket-ic-types.ts:397](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L397)

The subnet is a system subnet.

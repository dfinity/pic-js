---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:370](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L370)

The type of a subnet.

## Enumeration Members

### Application

> **Application**: `"Application"`

Defined in: [pocket-ic-types.ts:374](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L374)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [pocket-ic-types.ts:379](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L379)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [pocket-ic-types.ts:384](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L384)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [pocket-ic-types.ts:389](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L389)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [pocket-ic-types.ts:394](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L394)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [pocket-ic-types.ts:399](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L399)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [pocket-ic-types.ts:404](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L404)

The subnet is a system subnet.

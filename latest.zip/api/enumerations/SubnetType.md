---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:362](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L362)

The type of a subnet.


### Application

> **Application**: `"Application"`

Defined in: [pocket-ic-types.ts:366](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L366)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [pocket-ic-types.ts:371](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L371)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [pocket-ic-types.ts:376](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L376)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [pocket-ic-types.ts:381](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L381)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [pocket-ic-types.ts:386](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L386)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [pocket-ic-types.ts:391](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L391)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [pocket-ic-types.ts:396](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L396)

The subnet is a system subnet.

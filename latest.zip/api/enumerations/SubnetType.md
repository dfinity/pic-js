---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:475](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L475)

The type of a subnet.

## Enumeration Members

### Application

> **Application**: `"Application"`

Defined in: [packages/pic/src/pocket-ic-types.ts:479](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L479)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [packages/pic/src/pocket-ic-types.ts:484](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L484)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [packages/pic/src/pocket-ic-types.ts:489](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L489)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [packages/pic/src/pocket-ic-types.ts:499](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L499)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [packages/pic/src/pocket-ic-types.ts:504](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L504)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [packages/pic/src/pocket-ic-types.ts:509](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L509)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [packages/pic/src/pocket-ic-types.ts:514](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L514)

The subnet is a system subnet.

***

### TestThresholdKeys

> **TestThresholdKeys**: `"TestThresholdKeys"`

Defined in: [packages/pic/src/pocket-ic-types.ts:494](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L494)

The subnet is a test threshold keys subnet.

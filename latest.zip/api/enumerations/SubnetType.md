---
title: SubnetType
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:366](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L366)

The type of a subnet.

## Enumeration Members

### Application

> **Application**: `"Application"`

Defined in: [pocket-ic-types.ts:370](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L370)

The subnet is an application subnet.

***

### Bitcoin

> **Bitcoin**: `"Bitcoin"`

Defined in: [pocket-ic-types.ts:375](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L375)

The subnet is a Bitcoin subnet.

***

### Fiduciary

> **Fiduciary**: `"Fiduciary"`

Defined in: [pocket-ic-types.ts:380](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L380)

The subnet is a Fiduciary subnet.

***

### InternetIdentity

> **InternetIdentity**: `"II"`

Defined in: [pocket-ic-types.ts:385](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L385)

The subnet is an Internet Identity subnet.

***

### NNS

> **NNS**: `"NNS"`

Defined in: [pocket-ic-types.ts:390](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L390)

The subnet is a NNS subnet.

***

### SNS

> **SNS**: `"SNS"`

Defined in: [pocket-ic-types.ts:395](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L395)

The subnet is an SNS subnet.

***

### System

> **System**: `"System"`

Defined in: [pocket-ic-types.ts:400](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L400)

The subnet is a system subnet.

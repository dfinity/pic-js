---
title: PocketIcServer
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-server.ts:47](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-server.ts#L47)

This class represents the main PocketIC server.
It is responsible for maintaining the lifecycle of the server process.
See [PocketIc](PocketIc.md) for details on the client to use with this server.

## Example

```ts
import { PocketIc, PocketIcServer } from '@dfinity/pic';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const picServer = await PocketIcServer.start();
const pic = await PocketIc.create(picServer.getUrl());

const fixture = await pic.setupCanister<_SERVICE>({ idlFactory, wasmPath });
const { actor } = fixture;

// perform tests...

await pic.tearDown();
await picServer.stop();
```

## Methods

### getUrl()

> **getUrl**(): `string`

Defined in: [packages/pic/src/pocket-ic-server.ts:125](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-server.ts#L125)

Get the URL of the server.

#### Returns

`string`

The URL of the server.

***

### stop()

> **stop**(): `Promise`\<`void`\>

Defined in: [packages/pic/src/pocket-ic-server.ts:134](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-server.ts#L134)

Stop the server.

#### Returns

`Promise`\<`void`\>

A promise that resolves when the server has stopped.

***

### start()

> `static` **start**(`options?`): `Promise`\<`PocketIcServer`\>

Defined in: [packages/pic/src/pocket-ic-server.ts:63](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-server.ts#L63)

Start a new PocketIC server.

#### Parameters

##### options?

[`StartServerOptions`](../interfaces/StartServerOptions.md) = `{}`

Options for starting the server.

#### Returns

`Promise`\<`PocketIcServer`\>

An instance of the PocketIC server.

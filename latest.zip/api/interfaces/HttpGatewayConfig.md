---
title: HttpGatewayConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:123](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L123)

Options for the HTTP gateway created together with a PocketIC instance.

## Properties

### domains?

> `optional` **domains**: `string`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:137](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L137)

The domains the gateway serves canisters on. Defaults to `localhost`.

***

### httpsConfig?

> `optional` **httpsConfig**: [`HttpsConfig`](HttpsConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:142](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L142)

Serves the gateway over HTTPS with the given certificate and key.

***

### ipAddr?

> `optional` **ipAddr**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:127](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L127)

The IP address the gateway listens on. Defaults to `127.0.0.1`.

***

### port?

> `optional` **port**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:132](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L132)

The port the gateway listens on. Defaults to a free port.

---
title: StartCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:530](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L530)

Options for starting a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:534](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L534)

The Principal of the canister to start.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:540](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L540)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:545](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L545)

The ID of the subnet that the canister resides on.

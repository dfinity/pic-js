---
title: StartCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:534](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L534)

Options for starting a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:538](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L538)

The Principal of the canister to start.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:544](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L544)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:549](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L549)

The ID of the subnet that the canister resides on.

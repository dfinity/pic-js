---
title: IcpConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:254](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L254)

Configures IC protocol properties.


### betaFeatures?

> `optional` **betaFeatures**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:258](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L258)

Beta features (disabled on the ICP mainnet).

***

### canisterBacktrace?

> `optional` **canisterBacktrace**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:262](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L262)

Canister backtraces (enabled on the ICP mainnet).

***

### canisterExecutionRateLimiting?

> `optional` **canisterExecutionRateLimiting**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:271](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L271)

Rate-limiting of canister execution (enabled on the ICP mainnet).
Canister execution refers to instructions and memory writes here.

***

### functionNameLengthLimits?

> `optional` **functionNameLengthLimits**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [pocket-ic-types.ts:266](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L266)

Limits on function name length in canister WASM (enabled on the ICP mainnet).

---
title: IcpConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:302](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L302)

Configures IC protocol properties.

## Properties

### betaFeatures?

> `optional` **betaFeatures**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:306](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L306)

Beta features (disabled on the ICP mainnet).

***

### canisterBacktrace?

> `optional` **canisterBacktrace**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:310](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L310)

Canister backtraces (enabled on the ICP mainnet).

***

### canisterExecutionRateLimiting?

> `optional` **canisterExecutionRateLimiting**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:319](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L319)

Rate-limiting of canister execution (enabled on the ICP mainnet).
Canister execution refers to instructions and memory writes here.

***

### functionNameLengthLimits?

> `optional` **functionNameLengthLimits**: [`IcpConfigFlag`](../enumerations/IcpConfigFlag.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:314](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L314)

Limits on function name length in canister WASM (enabled on the ICP mainnet).

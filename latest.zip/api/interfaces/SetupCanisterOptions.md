---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:313](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L313)

Options for setting up a canister.


- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:330](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L330)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:374](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L374)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:369](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L369)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:403](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L403)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:384](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L384)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [pocket-ic-types.ts:317](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L317)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:379](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L379)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:389](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L389)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:336](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L336)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:420](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L420)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:414](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L414)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:324](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L324)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:414](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L414)

Options for setting up a canister.

## Extends

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:431](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L431)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty Uint8Array.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:475](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L475)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:470](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L470)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:504](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L504)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:485](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L485)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [packages/pic/src/pocket-ic-types.ts:418](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L418)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:480](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L480)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:490](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L490)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:437](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L437)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:521](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L521)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:515](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L515)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [packages/pic/src/pocket-ic-types.ts:425](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L425)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

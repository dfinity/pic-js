---
title: SetupCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:344](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L344)

Options for setting up a canister.


- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:361](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L361)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:405](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L405)

The compute allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`computeAllocation`](CreateCanisterOptions.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:400](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L400)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`controllers`](CreateCanisterOptions.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:434](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L434)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`cycles`](CreateCanisterOptions.md#cycles)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:415](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L415)

The freezing threshold of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`freezingThreshold`](CreateCanisterOptions.md#freezingthreshold)

***

### idlFactory

> **idlFactory**: `InterfaceFactory`

Defined in: [pocket-ic-types.ts:348](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L348)

The interface factory to use for the [Actor](Actor.md).

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:410](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L410)

The memory allocation of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`memoryAllocation`](CreateCanisterOptions.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:420](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L420)

The reserved cycles limit of the canister.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`reservedCyclesLimit`](CreateCanisterOptions.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:367](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L367)

The principal to setup the canister as.
Defaults to the anonymous principal.

#### Overrides

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`sender`](CreateCanisterOptions.md#sender)

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:451](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L451)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetCanisterId`](CreateCanisterOptions.md#targetcanisterid)

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:445](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L445)

The Id of the subnet to create the canister on.

#### Inherited from

[`CreateCanisterOptions`](CreateCanisterOptions.md).[`targetSubnetId`](CreateCanisterOptions.md#targetsubnetid)

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:355](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L355)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

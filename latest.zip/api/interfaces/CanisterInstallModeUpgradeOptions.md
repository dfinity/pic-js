---
title: CanisterInstallModeUpgradeOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/management-canister.ts:115](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/management-canister.ts#L115)

## Properties

### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/pic/src/management-canister.ts:116](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/management-canister.ts#L116)

***

### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[\] \| \[\{ `keep?`: `null`; `replace?`: `null`; \}\]

Defined in: [packages/pic/src/management-canister.ts:117](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/management-canister.ts#L117)

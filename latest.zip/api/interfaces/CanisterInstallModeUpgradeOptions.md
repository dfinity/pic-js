---
title: CanisterInstallModeUpgradeOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/management-canister.ts:159](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/management-canister.ts#L159)

## Properties

### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [packages/pic/src/management-canister.ts:160](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/management-canister.ts#L160)

***

### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[\] \| \[\{ `keep?`: `null`; `replace?`: `null`; \}\]

Defined in: [packages/pic/src/management-canister.ts:161](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/management-canister.ts#L161)

---
title: CanisterInstallModeUpgradeOptions
editUrl: false
next: true
prev: true
---

Defined in: [management-canister.ts:115](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/management-canister.ts#L115)

## Properties

### skip\_pre\_upgrade

> **skip\_pre\_upgrade**: \[\] \| \[`boolean`\]

Defined in: [management-canister.ts:116](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/management-canister.ts#L116)

***

### wasm\_memory\_persistence

> **wasm\_memory\_persistence**: \[\] \| \[\{ `keep?`: `null`; `replace?`: `null`; \}\]

Defined in: [management-canister.ts:117](https://github.com/dfinity/pic-js/blob/f1f786812455654da92d0fdaf03bc7d9fbc65144/packages/pic/src/management-canister.ts#L117)

---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:749](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L749)

The result of querying the status of a canister.
Matches the IC management canister `canister_status` response.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:779](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L779)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:789](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L789)

The amount of cycles burned per day when idle.

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:774](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L774)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:769](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L769)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:794](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L794)

Query call statistics for the canister.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:784](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L784)

The reserved cycles of the canister.

***

### settings

> **settings**: `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:758](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L758)

The definite settings of the canister.

#### computeAllocation

> **computeAllocation**: `bigint`

#### controllers

> **controllers**: `Principal`[]

#### freezingThreshold

> **freezingThreshold**: `bigint`

#### memoryAllocation

> **memoryAllocation**: `bigint`

#### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:753](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L753)

The current status of the canister.

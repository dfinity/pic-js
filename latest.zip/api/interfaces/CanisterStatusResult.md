---
title: CanisterStatusResult
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:953](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L953)

The result of querying the status of a canister.
This is a subset of the IC management canister `canister_status` response.
Some fields (e.g. `snapshotVisibility`, `logMemoryLimit`, `memoryMetrics`)
are not yet included because the PocketIC server does not return them.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### cycles

> **cycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:987](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L987)

The current cycle balance of the canister.

***

### idleCyclesBurnedPerDay

> **idleCyclesBurnedPerDay**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:997](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L997)

The amount of cycles burned per day when idle.

***

### memorySize

> **memorySize**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:982](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L982)

The total memory size of the canister in bytes.

***

### moduleHash

> **moduleHash**: `Uint8Array`\<`ArrayBufferLike`\> \| `null`

Defined in: [packages/pic/src/pocket-ic-types.ts:977](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L977)

The SHA-256 hash of the installed WASM module, if any.

***

### queryStats

> **queryStats**: [`CanisterQueryStats`](CanisterQueryStats.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1002](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1002)

Query call statistics for the canister.

***

### reservedCycles

> **reservedCycles**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:992](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L992)

The reserved cycles of the canister.

***

### settings

> **settings**: `object`

Defined in: [packages/pic/src/pocket-ic-types.ts:962](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L962)

The definite settings of the canister.

#### computeAllocation

> **computeAllocation**: `bigint`

#### controllers

> **controllers**: `Principal`[]

#### environmentVariables

> **environmentVariables**: [`EnvironmentVariable`](EnvironmentVariable.md)[]

#### freezingThreshold

> **freezingThreshold**: `bigint`

#### logVisibility

> **logVisibility**: [`LogVisibility`](../type-aliases/LogVisibility.md)

#### memoryAllocation

> **memoryAllocation**: `bigint`

#### reservedCyclesLimit

> **reservedCyclesLimit**: `bigint`

#### wasmMemoryLimit

> **wasmMemoryLimit**: `bigint`

#### wasmMemoryThreshold

> **wasmMemoryThreshold**: `bigint`

***

### status

> **status**: [`CanisterStatus`](../type-aliases/CanisterStatus.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:957](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L957)

The current status of the canister.

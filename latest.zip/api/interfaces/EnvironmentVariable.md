---
title: EnvironmentVariable
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:603](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L603)

Environment variable for canister settings.

## Properties

### name

> **name**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:604](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L604)

***

### value

> **value**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:605](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L605)

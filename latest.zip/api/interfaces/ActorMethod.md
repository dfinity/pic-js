---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-actor.ts:12](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-actor.ts#L12)

Typesafe method of a canister.

## Type Parameters

### Args

`Args` *extends* `any`[] = `any`[]

### Ret

`Ret` = `any`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [packages/pic/src/pocket-ic-actor.ts:13](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-actor.ts#L13)

Typesafe method of a canister.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

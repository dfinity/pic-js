---
title: ActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-actor.ts:12](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-actor.ts#L12)

Typesafe method of a canister.


### Args

`Args` *extends* `any`[] = `any`[]

### Ret

`Ret` = `any`

> **ActorMethod**(...`args`): `Promise`\<`Ret`\>

Defined in: [pocket-ic-actor.ts:13](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-actor.ts#L13)

Typesafe method of a canister.

## Parameters

### args

...`Args`

## Returns

`Promise`\<`Ret`\>

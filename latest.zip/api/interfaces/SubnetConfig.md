---
title: SubnetConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:90](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L90)

Common options for creating a subnet.

## Type Parameters

### T

`T` *extends* [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md) = [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md)

## Properties

### enableBenchmarkingInstructionLimits?

> `optional` **enableBenchmarkingInstructionLimits**: `boolean`

Defined in: [pocket-ic-types.ts:105](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L105)

Whether to enable benchmarking instruction limits.
Defaults to `false`.

***

### enableDeterministicTimeSlicing?

> `optional` **enableDeterministicTimeSlicing**: `boolean`

Defined in: [pocket-ic-types.ts:99](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L99)

Whether to enable deterministic time slicing.
Defaults to `true`.

***

### state

> **state**: `T`

Defined in: [pocket-ic-types.ts:110](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L110)

The state configuration for the subnet.

---
title: UpdateCallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:642](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L642)

Options for making an update call to a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:663](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L663)

A Candid encoded argument to pass to the canister's method.
Defaults to an empty ArrayBuffer.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:652](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L652)

The Principal of the canister to update.

***

### method

> **method**: `string`

Defined in: [pocket-ic-types.ts:657](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L657)

The method to call on the canister.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:647](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L647)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:668](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L668)

The ID of the subnet that the canister resides on.

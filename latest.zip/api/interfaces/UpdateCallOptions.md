---
title: UpdateCallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:735](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L735)

Options for making an update call to a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:756](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L756)

A Candid encoded argument to pass to the canister's method.
Defaults to an empty ArrayBuffer.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:745](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L745)

The Principal of the canister to update.

***

### method

> **method**: `string`

Defined in: [pocket-ic-types.ts:750](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L750)

The method to call on the canister.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:740](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L740)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:761](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L761)

The ID of the subnet that the canister resides on.

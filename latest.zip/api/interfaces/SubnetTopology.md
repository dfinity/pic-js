---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:241](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L241)

The topology of a subnet.


### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [pocket-ic-types.ts:260](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L260)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [pocket-ic-types.ts:245](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L245)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [pocket-ic-types.ts:255](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L255)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [pocket-ic-types.ts:250](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L250)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

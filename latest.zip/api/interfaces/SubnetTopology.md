---
title: SubnetTopology
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:447](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L447)

The topology of a subnet.

## Properties

### canisterRanges

> **canisterRanges**: `object`[]

Defined in: [packages/pic/src/pocket-ic-types.ts:466](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L466)

The range of canister IDs that can be deployed to the subnet.

#### end

> **end**: `Principal`

#### start

> **start**: `Principal`

***

### id

> **id**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:451](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L451)

The subnet ID.

***

### size

> **size**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:461](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L461)

The number of nodes in the subnet.

***

### type

> **type**: [`SubnetType`](../enumerations/SubnetType.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:456](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L456)

The subnet type. See [SubnetType](../enumerations/SubnetType.md).

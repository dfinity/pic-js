---
title: ReinstallCodeOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:616](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L616)

Options for reinstalling a WASM module to a given canister.
This will reset both the canister's heap and its stable memory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:632](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L632)

Candid encoded argument to pass to the canister's init function.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:620](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L620)

The Principal of the canister to reinstall code to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:638](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L638)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:627](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L627)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

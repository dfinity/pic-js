---
title: Actor
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-actor.ts:32](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-actor.ts#L32)

A type-safe class that implements the Candid interface of a canister.
This is acquired by calling [setupCanister](../classes/PocketIc.md#setupcanister)
or [createActor](../classes/PocketIc.md#createactor).

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

The type of the Actor. Must implement [ActorInterface](../type-aliases/ActorInterface.md).

## Methods

### setIdentity()

> **setIdentity**(`identity`): `void`

Defined in: [packages/pic/src/pocket-ic-actor.ts:87](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-actor.ts#L87)

Set a Principal to be used as sender for all calls to the canister.
This is a convenience method over [setPrincipal](#setprincipal) that accepts an
Identity and internally extracts the Principal.

#### Parameters

##### identity

`Identity`

The identity to set.

#### Returns

`void`

#### See

 - [Identity](https://js.icp.build/core/latest/libs/agent/api/#identity-9)
 - [Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

#### Example

```ts
import { PocketIc } from '@dfinity/pic';
import { AnonymousIdentity } from '@icp-sdk/core/agent';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const pic = await PocketIc.create();
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

actor.setIdentity(new AnonymousIdentity());
```

***

### setPrincipal()

> **setPrincipal**(`principal`): `void`

Defined in: [packages/pic/src/pocket-ic-actor.ts:60](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-actor.ts#L60)

Set a Principal to be used as sender for all calls to the canister.

#### Parameters

##### principal

`Principal`

The Principal to set.

#### Returns

`void`

#### See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

#### Example

```ts
import { PocketIc } from '@dfinity/pic';
import { Principal } from '@icp-sdk/core/principal';
import { _SERVICE, idlFactory } from '../declarations';

const wasmPath = resolve('..', '..', 'canister.wasm');

const pic = await PocketIc.create();
const fixture = await pic.setupCanister<_SERVICE>(idlFactory, wasmPath);
const { actor } = fixture;

actor.setPrincipal(Principal.anonymous());
```

---
title: StartServerOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-server-types.ts:4](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-server-types.ts#L4)

Options for starting a PocketIC server.


### showCanisterLogs?

> `optional` **showCanisterLogs**: `boolean`

Defined in: [pocket-ic-server-types.ts:13](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-server-types.ts#L13)

Whether to pipe the canister logs to the parent process's stderr.

***

### showRuntimeLogs?

> `optional` **showRuntimeLogs**: `boolean`

Defined in: [pocket-ic-server-types.ts:8](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-server-types.ts#L8)

Whether to pipe the runtimes's logs to the parent process's stdout.

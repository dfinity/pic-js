---
title: FetchCanisterLogsOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1268](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1268)

Options for fetching canister logs.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1272](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1272)

The Principal of the canister to fetch logs for.

***

### filter?

> `optional` **filter**: [`CanisterLogFilter`](../type-aliases/CanisterLogFilter.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:1289](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1289)

Only return the log records in the given range.
Defaults to all log records.

***

### sender

> **sender**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1283](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1283)

The Principal to send the request as.

By default, only a canister's controllers can read its logs. Other principals,
including the anonymous principal, need the canister's
[log visibility](https://docs.internetcomputer.org/guides/canister-management/settings/#log-visibility)
to allow them, e.g. `logVisibility: { public: null }` or
`logVisibility: { allowedViewers: [principal] }` in [PocketIc.updateCanisterSettings](../classes/PocketIc.md#updatecanistersettings).

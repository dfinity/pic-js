---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:193](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L193)

Options for creating a new subnet an empty state.


### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [pocket-ic-types.ts:197](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L197)

The type of subnet state to initialize the subnet with.

---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:187](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L187)

Options for creating a new subnet an empty state.


### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [pocket-ic-types.ts:191](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L191)

The type of subnet state to initialize the subnet with.

---
title: NewSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:192](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L192)

Options for creating a new subnet an empty state.


### type

> **type**: [`New`](../enumerations/SubnetStateType.md#new)

Defined in: [pocket-ic-types.ts:196](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L196)

The type of subnet state to initialize the subnet with.

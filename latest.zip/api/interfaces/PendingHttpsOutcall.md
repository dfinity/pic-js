---
title: PendingHttpsOutcall
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:780](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L780)

A pending HTTPS outcall.

## Properties

### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:810](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L810)

The body of the pending request.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:805](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L805)

The headers of the pending request.

***

### httpMethod

> **httpMethod**: [`CanisterHttpMethod`](../enumerations/CanisterHttpMethod.md)

Defined in: [pocket-ic-types.ts:795](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L795)

The HTTP method used for this request.

***

### maxResponseBytes?

> `optional` **maxResponseBytes**: `number`

Defined in: [pocket-ic-types.ts:816](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L816)

The maximum number of bytes expected in the response body that was set
by the canister making the request.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:790](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L790)

The HTTPS Outcall request Id. Use this Id when setting a mock response
for this request.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:784](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L784)

The subnet ID to that the HTTPS Outcall is being sent from.

***

### url

> **url**: `string`

Defined in: [pocket-ic-types.ts:800](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L800)

The target URL of the pending request.

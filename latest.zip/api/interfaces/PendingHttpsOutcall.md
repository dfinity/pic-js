---
title: PendingHttpsOutcall
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:709](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L709)

A pending HTTPS outcall.


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:739](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L739)

The body of the pending request.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:734](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L734)

The headers of the pending request.

***

### httpMethod

> **httpMethod**: [`CanisterHttpMethod`](../enumerations/CanisterHttpMethod.md)

Defined in: [pocket-ic-types.ts:724](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L724)

The HTTP method used for this request.

***

### maxResponseBytes?

> `optional` **maxResponseBytes**: `number`

Defined in: [pocket-ic-types.ts:745](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L745)

The maximum number of bytes expected in the response body that was set
by the canister making the request.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:719](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L719)

The HTTPS Outcall request Id. Use this Id when setting a mock response
for this request.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:713](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L713)

The subnet ID to that the HTTPS Outcall is being sent from.

***

### url

> **url**: `string`

Defined in: [pocket-ic-types.ts:729](https://github.com/dfinity/pic-js/blob/49983e2927ee88a6f5612c198b76c5de8543fe2e/packages/pic/src/pocket-ic-types.ts#L729)

The target URL of the pending request.

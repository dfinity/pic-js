---
title: PendingHttpsOutcall
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:777](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L777)

A pending HTTPS outcall.


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:807](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L807)

The body of the pending request.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:802](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L802)

The headers of the pending request.

***

### httpMethod

> **httpMethod**: [`CanisterHttpMethod`](../enumerations/CanisterHttpMethod.md)

Defined in: [pocket-ic-types.ts:792](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L792)

The HTTP method used for this request.

***

### maxResponseBytes?

> `optional` **maxResponseBytes**: `number`

Defined in: [pocket-ic-types.ts:813](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L813)

The maximum number of bytes expected in the response body that was set
by the canister making the request.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:787](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L787)

The HTTPS Outcall request Id. Use this Id when setting a mock response
for this request.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:781](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L781)

The subnet ID to that the HTTPS Outcall is being sent from.

***

### url

> **url**: `string`

Defined in: [pocket-ic-types.ts:797](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L797)

The target URL of the pending request.

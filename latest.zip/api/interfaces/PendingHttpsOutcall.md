---
title: PendingHttpsOutcall
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:771](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L771)

A pending HTTPS outcall.


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:801](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L801)

The body of the pending request.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:796](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L796)

The headers of the pending request.

***

### httpMethod

> **httpMethod**: [`CanisterHttpMethod`](../enumerations/CanisterHttpMethod.md)

Defined in: [pocket-ic-types.ts:786](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L786)

The HTTP method used for this request.

***

### maxResponseBytes?

> `optional` **maxResponseBytes**: `number`

Defined in: [pocket-ic-types.ts:807](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L807)

The maximum number of bytes expected in the response body that was set
by the canister making the request.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:781](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L781)

The HTTPS Outcall request Id. Use this Id when setting a mock response
for this request.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:775](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L775)

The subnet ID to that the HTTPS Outcall is being sent from.

***

### url

> **url**: `string`

Defined in: [pocket-ic-types.ts:791](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L791)

The target URL of the pending request.

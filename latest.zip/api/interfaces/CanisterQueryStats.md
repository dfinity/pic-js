---
title: CanisterQueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:735](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L735)

Query statistics for a canister.

## Properties

### numCallsTotal

> **numCallsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:736](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L736)

***

### numInstructionsTotal

> **numInstructionsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:737](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L737)

***

### requestPayloadBytesTotal

> **requestPayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:738](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L738)

***

### responsePayloadBytesTotal

> **responsePayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:739](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L739)

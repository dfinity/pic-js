---
title: CanisterQueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:838](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L838)

Query statistics for a canister.

## Properties

### numCallsTotal

> **numCallsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:839](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L839)

***

### numInstructionsTotal

> **numInstructionsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:840](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L840)

***

### requestPayloadBytesTotal

> **requestPayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:841](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L841)

***

### responsePayloadBytesTotal

> **responsePayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:842](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L842)

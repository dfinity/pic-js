---
title: CanisterQueryStats
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:937](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L937)

Query statistics for a canister.

## Properties

### numCallsTotal

> **numCallsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:938](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L938)

***

### numInstructionsTotal

> **numInstructionsTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:939](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L939)

***

### requestPayloadBytesTotal

> **requestPayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:940](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L940)

***

### responsePayloadBytesTotal

> **responsePayloadBytesTotal**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:941](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L941)

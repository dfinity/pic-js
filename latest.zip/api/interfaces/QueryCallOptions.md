---
title: QueryCallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:705](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L705)

Options for making a query call to a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:726](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L726)

A Candid encoded argument to pass to the canister's method.
Defaults to an empty ArrayBuffer.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:715](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L715)

The Principal of the canister to query.

***

### method

> **method**: `string`

Defined in: [pocket-ic-types.ts:720](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L720)

The method to call on the canister.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:710](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L710)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:731](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L731)

The ID of the subnet that the canister resides on.

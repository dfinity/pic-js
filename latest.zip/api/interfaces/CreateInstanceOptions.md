---
title: CreateInstanceOptions
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:14](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L14)

Options for creating a PocketIc instance.

## Properties

### application?

> `optional` **application**: [`ApplicationSubnetConfig`](../type-aliases/ApplicationSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:66](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L66)

Configuration options for creating application subnets.
An application subnet will be created for each configuration object provided.
If no config objects are provided, no application subnets are setup.

***

### bitcoin?

> `optional` **bitcoin**: [`BitcoinSubnetConfig`](../type-aliases/BitcoinSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:52](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L52)

Configuration options for creating a Bitcoin subnet.
If no config is provided, the Bitcoin subnet is not setup.

***

### disableIngressValidation?

> `optional` **disableIngressValidation**: `boolean`

Defined in: [packages/pic/src/pocket-ic-types.ts:117](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L117)

Disables ingress message validation on the PocketIC instance.

When enabled, the PocketIC server skips the validation that would normally
reject malformed or otherwise invalid ingress messages. This is useful for
testing canister behavior against ingress messages that the replica would
ordinarily refuse to process.

Defaults to `false`.

***

### fiduciary?

> `optional` **fiduciary**: [`FiduciarySubnetConfig`](../type-aliases/FiduciarySubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:38](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L38)

Configuration options for creating a Fiduciary subnet.
If no config is provided, the Fiduciary subnet is not setup.
Like on mainnet, the II and Fiduciary subnets hold the `key_1` threshold keys.

***

### httpGateway?

> `optional` **httpGateway**: [`HttpGatewayConfig`](HttpGatewayConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:105](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L105)

Creates an HTTP gateway together with the PocketIC instance.
Required by the `ii` and `nnsUi` ICP features.

The gateway serves requests once the instance is live,
see [PocketIc.makeLive](../classes/PocketIc.md#makelive), which returns the gateway's port.

***

### icpConfig?

> `optional` **icpConfig**: [`IcpConfig`](IcpConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:91](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L91)

Determines what non-mainnet features should be
enabled for the PocketIC instance.

***

### icpFeatures?

> `optional` **icpFeatures**: [`IcpFeatures`](IcpFeatures.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:96](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L96)

Determines what ICP features should be enabled for the PocketIC instance.

***

### ii?

> `optional` **ii**: [`IiSubnetConfig`](../type-aliases/IiSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:31](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L31)

Configuration options for creating an II subnet.
If no config is provided, the II subnet is not setup.

***

### ~~ingressMaxRetries?~~

> `optional` **ingressMaxRetries**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:86](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L86)

#### Deprecated

This option is no longer used. The PocketIC server now handles
ingress message processing internally via the `await_ingress_message` endpoint.
Use [CreateInstanceOptions.processingTimeoutMs](#processingtimeoutms) to control how long update
calls can wait for ingress processing to complete.

***

### nns?

> `optional` **nns**: [`NnsSubnetConfig`](../type-aliases/NnsSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:19](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L19)

Configuration options for creating an NNS subnet.
If no config is provided, the NNS subnet is not setup.

***

### processingTimeoutMs?

> `optional` **processingTimeoutMs**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:78](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L78)

How long the PocketIC client should wait for a response from the server.

***

### sns?

> `optional` **sns**: [`SnsSubnetConfig`](../type-aliases/SnsSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:25](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L25)

Configuration options for creating an SNS subnet.
If no config is provided, the SNS subnet is not setup.

***

### system?

> `optional` **system**: [`SystemSubnetConfig`](../type-aliases/SystemSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:59](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L59)

Configuration options for creating system subnets.
A system subnet will be created for each configuration object provided.
If no config objects are provided, no system subnets are setup.

***

### testThresholdKeys?

> `optional` **testThresholdKeys**: [`TestThresholdKeysSubnetConfig`](../type-aliases/TestThresholdKeysSubnetConfig.md)

Defined in: [packages/pic/src/pocket-ic-types.ts:46](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L46)

Configuration options for creating a test threshold keys subnet.
If no config is provided, the test threshold keys subnet is not setup.
Like on mainnet, it is the subnet that holds the `test_key_1` threshold keys
for ECDSA, Schnorr and vetKD, so it is required to sign with or derive from them.

***

### verifiedApplication?

> `optional` **verifiedApplication**: [`VerifiedApplicationSubnetConfig`](../type-aliases/VerifiedApplicationSubnetConfig.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:73](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L73)

Configuration options for creating verified application subnets.
A verified application subnet will be created for each configuration object provided.
If no config objects are provided, no verified application subnets are setup.

---
title: CreateInstanceOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:10](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L10)

Options for creating a PocketIc instance.


### application?

> `optional` **application**: [`ApplicationSubnetConfig`](../type-aliases/ApplicationSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:53](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L53)

Configuration options for creating application subnets.
An application subnet will be created for each configuration object provided.
If no config objects are provided, no application subnets are setup.

***

### bitcoin?

> `optional` **bitcoin**: [`BitcoinSubnetConfig`](../type-aliases/BitcoinSubnetConfig.md)

Defined in: [pocket-ic-types.ts:39](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L39)

Configuration options for creating a Bitcoin subnet.
If no config is provided, the Bitcoin subnet is not setup.

***

### fiduciary?

> `optional` **fiduciary**: [`FiduciarySubnetConfig`](../type-aliases/FiduciarySubnetConfig.md)

Defined in: [pocket-ic-types.ts:33](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L33)

Configuration options for creating a Fiduciary subnet.
If no config is provided, the Fiduciary subnet is not setup.

***

### icpConfig?

> `optional` **icpConfig**: [`IcpConfig`](IcpConfig.md)

Defined in: [pocket-ic-types.ts:71](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L71)

Determines what non-mainnet features should be
enabled for the PocketIC instance.

***

### icpFeatures?

> `optional` **icpFeatures**: [`IcpFeatures`](IcpFeatures.md)

Defined in: [pocket-ic-types.ts:76](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L76)

Determines what ICP features should be enabled for the PocketIC instance.

***

### ii?

> `optional` **ii**: [`IiSubnetConfig`](../type-aliases/IiSubnetConfig.md)

Defined in: [pocket-ic-types.ts:27](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L27)

Configuration options for creating an II subnet.
If no config is provided, the II subnet is not setup.

***

### nns?

> `optional` **nns**: [`NnsSubnetConfig`](../type-aliases/NnsSubnetConfig.md)

Defined in: [pocket-ic-types.ts:15](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L15)

Configuration options for creating an NNS subnet.
If no config is provided, the NNS subnet is not setup.

***

### processingTimeoutMs?

> `optional` **processingTimeoutMs**: `number`

Defined in: [pocket-ic-types.ts:65](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L65)

How long the PocketIC client should wait for a response from the server.

***

### sns?

> `optional` **sns**: [`SnsSubnetConfig`](../type-aliases/SnsSubnetConfig.md)

Defined in: [pocket-ic-types.ts:21](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L21)

Configuration options for creating an SNS subnet.
If no config is provided, the SNS subnet is not setup.

***

### system?

> `optional` **system**: [`SystemSubnetConfig`](../type-aliases/SystemSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:46](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L46)

Configuration options for creating system subnets.
A system subnet will be created for each configuration object provided.
If no config objects are provided, no system subnets are setup.

***

### verifiedApplication?

> `optional` **verifiedApplication**: [`VerifiedApplicationSubnetConfig`](../type-aliases/VerifiedApplicationSubnetConfig.md)[]

Defined in: [pocket-ic-types.ts:60](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L60)

Configuration options for creating verified application subnets.
A verified application subnet will be created for each configuration object provided.
If no config objects are provided, no verified application subnets are setup.

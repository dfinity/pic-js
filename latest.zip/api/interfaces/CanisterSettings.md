---
title: CanisterSettings
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:461](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L461)

Canister settings.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extended by

- [`CreateCanisterOptions`](CreateCanisterOptions.md)

## Properties

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:471](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L471)

The compute allocation of the canister.

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:466](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L466)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:481](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L481)

The freezing threshold of the canister.

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:476](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L476)

The memory allocation of the canister.

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:486](https://github.com/dfinity/pic-js/blob/12b3bb43d31d5555995a8b15cd95e2ae3b2d2729/packages/pic/src/pocket-ic-types.ts#L486)

The reserved cycles limit of the canister.

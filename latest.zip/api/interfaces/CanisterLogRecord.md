---
title: CanisterLogRecord
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1336](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1336)

A canister log record.

## Properties

### content

> **content**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1350](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1350)

The content of the log record.

***

### idx

> **idx**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1340](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1340)

The index of the log record.

***

### timestampNanos

> **timestampNanos**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1345](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1345)

The timestamp of the log record in nanoseconds since epoch.

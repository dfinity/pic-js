---
title: HttpsConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:148](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L148)

Paths to the certificate and key used to serve an HTTP gateway over HTTPS.

## Properties

### certPath

> **certPath**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:149](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L149)

***

### keyPath

> **keyPath**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:150](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L150)

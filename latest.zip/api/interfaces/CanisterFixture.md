---
title: CanisterFixture
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:440](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L440)

A canister testing fixture for PocketIC that provides essential testing primitives
such as an [Actor](Actor.md) and CanisterId.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

## Properties

### actor

> **actor**: [`Actor`](Actor.md)\<`T`\>

Defined in: [pocket-ic-types.ts:444](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L444)

The [Actor](Actor.md) instance.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:449](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L449)

The Principal of the canister.

---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1241](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1241)

## Properties

### message

> **message**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1255](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1255)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1250](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1250)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1245](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1245)

The type of the response, either `'reject'` or `'response'`.

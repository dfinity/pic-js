---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:892](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L892)


### message

> **message**: `string`

Defined in: [pocket-ic-types.ts:906](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L906)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:901](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L901)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [pocket-ic-types.ts:896](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L896)

The type of the response, either `'reject'` or `'response'`.

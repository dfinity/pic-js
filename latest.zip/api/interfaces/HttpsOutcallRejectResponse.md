---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1000](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L1000)

## Properties

### message

> **message**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:1014](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L1014)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:1009](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L1009)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1004](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L1004)

The type of the response, either `'reject'` or `'response'`.

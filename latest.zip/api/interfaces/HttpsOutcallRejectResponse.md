---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:905](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L905)

## Properties

### message

> **message**: `string`

Defined in: [pocket-ic-types.ts:919](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L919)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:914](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L914)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [pocket-ic-types.ts:909](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L909)

The type of the response, either `'reject'` or `'response'`.

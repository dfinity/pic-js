---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:799](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L799)


### message

> **message**: `string`

Defined in: [pocket-ic-types.ts:813](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L813)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:808](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L808)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [pocket-ic-types.ts:803](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L803)

The type of the response, either `'reject'` or `'response'`.

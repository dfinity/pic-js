---
title: HttpsOutcallRejectResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:901](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L901)

## Properties

### message

> **message**: `string`

Defined in: [pocket-ic-types.ts:915](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L915)

The message of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:910](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L910)

The status code of the response.

***

### type

> **type**: `"reject"`

Defined in: [pocket-ic-types.ts:905](https://github.com/dfinity/pic-js/blob/c06bddf81c4d42f538e7fbb18b8fd249da928b65/packages/pic/src/pocket-ic-types.ts#L905)

The type of the response, either `'reject'` or `'response'`.

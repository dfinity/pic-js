---
title: DeferredActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-deferred-actor.ts:8](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-deferred-actor.ts#L8)


### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **DeferredActorMethod**(...`args`): `Promise`\<() => `Promise`\<`Ret`\>\>

Defined in: [pocket-ic-deferred-actor.ts:12](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-deferred-actor.ts#L12)

## Parameters

### args

...`Args`

## Returns

`Promise`\<() => `Promise`\<`Ret`\>\>

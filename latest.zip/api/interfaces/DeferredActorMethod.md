---
title: DeferredActorMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-deferred-actor.ts:8](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-deferred-actor.ts#L8)


### Args

`Args` *extends* `unknown`[] = `unknown`[]

### Ret

`Ret` = `unknown`

> **DeferredActorMethod**(...`args`): `Promise`\<() => `Promise`\<`Ret`\>\>

Defined in: [pocket-ic-deferred-actor.ts:12](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-deferred-actor.ts#L12)

## Parameters

### args

...`Args`

## Returns

`Promise`\<() => `Promise`\<`Ret`\>\>

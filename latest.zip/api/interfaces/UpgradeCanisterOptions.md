---
title: UpgradeCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:652](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L652)

Options for upgrading a given canister with a WASM module.
This will reset the canister's heap, but preserve stable memory.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:668](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L668)

Candid encoded argument to pass to the canister's init function.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:656](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L656)

The Principal of the canister to upgrade.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:674](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L674)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### upgradeModeOptions?

> `optional` **upgradeModeOptions**: [`CanisterInstallModeUpgradeOptions`](CanisterInstallModeUpgradeOptions.md)

Defined in: [pocket-ic-types.ts:679](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L679)

The options to pass to the management canister's upgrade variant in the install code request.

***

### wasm

> **wasm**: `string` \| `Uint8Array`\<`ArrayBufferLike`\>

Defined in: [pocket-ic-types.ts:663](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L663)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `Uint8Array` is passed, it is treated as the WASM module itself.

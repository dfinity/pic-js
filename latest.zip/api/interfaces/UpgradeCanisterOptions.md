---
title: UpgradeCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:644](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L644)

Options for upgrading a given canister with a WASM module.
This will reset the canister's heap, but preserve stable memory.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:660](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L660)

Candid encoded argument to pass to the canister's init function.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:648](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L648)

The Principal of the canister to upgrade.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:666](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L666)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:655](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L655)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:883](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L883)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:902](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L902)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:897](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L897)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:892](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L892)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [pocket-ic-types.ts:887](https://github.com/dfinity/pic-js/blob/c0f6c5cebca991769e53fff8aa9098d9fb6a79b8/packages/pic/src/pocket-ic-types.ts#L887)

The type of the response, either `'success'` or `'response'`.

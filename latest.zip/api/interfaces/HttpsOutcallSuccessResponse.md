---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:978](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L978)

## Properties

### body

> **body**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:997](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L997)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [packages/pic/src/pocket-ic-types.ts:992](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L992)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [packages/pic/src/pocket-ic-types.ts:987](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L987)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [packages/pic/src/pocket-ic-types.ts:982](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L982)

The type of the response, either `'success'` or `'response'`.

---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:870](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L870)


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:889](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L889)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:884](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L884)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:879](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L879)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [pocket-ic-types.ts:874](https://github.com/dfinity/pic-js/blob/ee65498a38f705390c9f6cf0a77779deab25b140/packages/pic/src/pocket-ic-types.ts#L874)

The type of the response, either `'success'` or `'response'`.

---
title: SenderInfo
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1020](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1020)

Sender information attached to a canister call.

This is passed through to the canister, which can inspect it via the
`msg_caller_info_data` and `msg_caller_info_signer` system APIs. PocketIC
does not validate or verify anything; it simply forwards both fields for
canister inspection, mocking the signer's signature.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/#principal)

## Properties

### info

> **info**: `Uint8Array`

Defined in: [packages/pic/src/pocket-ic-types.ts:1024](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1024)

An arbitrary binary blob of sender information.

***

### signer

> **signer**: `Principal`

Defined in: [packages/pic/src/pocket-ic-types.ts:1029](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1029)

The Principal of the canister whose signature will be mocked.

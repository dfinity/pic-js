---
title: CanisterLogTimestampFilter
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1319](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1319)

Selects the log records whose timestamp is in the range `[start, end)`.

## Properties

### end

> **end**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1330](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1330)

The timestamp to stop before, in nanoseconds since epoch (exclusive).

***

### start

> **start**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1325](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1325)

The first timestamp to return, in nanoseconds since epoch (inclusive).

***

### type

> **type**: `"byTimestampNanos"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1320](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1320)

---
title: CanisterLogIdxFilter
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:1302](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1302)

Selects the log records whose index is in the range `[start, end)`.

## Properties

### end

> **end**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1313](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1313)

The index to stop before (exclusive).

***

### start

> **start**: `bigint`

Defined in: [packages/pic/src/pocket-ic-types.ts:1308](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1308)

The first index to return (inclusive).

***

### type

> **type**: `"byIdx"`

Defined in: [packages/pic/src/pocket-ic-types.ts:1303](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L1303)

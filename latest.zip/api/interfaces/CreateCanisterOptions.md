---
title: CreateCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:492](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L492)

Options for creating a canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extends

- [`CanisterSettings`](CanisterSettings.md)

## Extended by

- [`SetupCanisterOptions`](SetupCanisterOptions.md)

## Properties

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:468](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L468)

The compute allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`computeAllocation`](CanisterSettings.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:463](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L463)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`controllers`](CanisterSettings.md#controllers)

***

### cycles?

> `optional` **cycles**: `bigint`

Defined in: [pocket-ic-types.ts:497](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L497)

The amount of cycles to send to the canister.
Defaults to 1_000_000_000_000_000_000n.

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:478](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L478)

The freezing threshold of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`freezingThreshold`](CanisterSettings.md#freezingthreshold)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:473](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L473)

The memory allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`memoryAllocation`](CanisterSettings.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:483](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L483)

The reserved cycles limit of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`reservedCyclesLimit`](CanisterSettings.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:503](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L503)

The principal to create the canister as.
Defaults to the anonymous principal.

***

### targetCanisterId?

> `optional` **targetCanisterId**: `Principal`

Defined in: [pocket-ic-types.ts:514](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L514)

The Id of the canister to create.
Can only be used on Bitcoin, Fiduciary, II, SNS and NNS subnets.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:508](https://github.com/dfinity/pic-js/blob/d06f0272fbd5943904acfbf7fe798c7c5e6994c1/packages/pic/src/pocket-ic-types.ts#L508)

The Id of the subnet to create the canister on.

---
title: IcpFeatures
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:400](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L400)

Specifies ICP features enabled by deploying their corresponding system canisters
when creating a PocketIC instance and keeping them up to date during the PocketIC instance lifetime.
The subnets to which the corresponding system canisters are deployed must be empty.
An ICP feature is enabled if its `IcpFeaturesConfig` is provided, i.e., if the corresponding field is set.

## Properties

### cyclesMinting?

> `optional` **cyclesMinting**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:412](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L412)

Deploys the NNS cycles minting canister, sets ICP/XDR conversion rate, and keeps its subnet lists in sync with PocketIC topology.
If enabled, the default timestamp of a PocketIC instance is set to 10 May 2021 10:00:01 AM CEST
(the smallest value that is strictly larger than the default timestamp hard-coded in the CMC state).

***

### cyclesToken?

> `optional` **cyclesToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:420](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L420)

Deploys the cycles ledger and index canisters and initializes the cycles account of the anonymous principal with 2^127 - 1 cycles.

***

### icpToken?

> `optional` **icpToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:416](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L416)

Deploys the ICP ledger and index canisters and initializes the ICP account of the anonymous principal with 1,000,000,000 ICP.

***

### ii?

> `optional` **ii**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:435](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L435)

Deploys the Internet Identity backend and frontend canisters.
Requires [CreateInstanceOptions.httpGateway](CreateInstanceOptions.md#httpgateway).

***

### nnsGovernance?

> `optional` **nnsGovernance**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:425](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L425)

Deploys the NNS governance and root canisters and sets up an initial NNS neuron with 1 ICP stake.
The initial NNS neuron is controlled by the anonymous principal.

***

### nnsUi?

> `optional` **nnsUi**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:441](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L441)

Deploys the NNS frontend dapp.
Requires [CreateInstanceOptions.httpGateway](CreateInstanceOptions.md#httpgateway) and the `cyclesMinting`,
`icpToken`, `nnsGovernance`, `sns` and `ii` features.

***

### registry?

> `optional` **registry**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:406](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L406)

Deploys the NNS registry canister and keeps its content in sync with registry used internally by PocketIC.
Note. The registry used internally by PocketIC is not updated after changing the registry stored in the registry canister
(e.g., after executing an NNS proposal mutating the registry).

***

### sns?

> `optional` **sns**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:430](https://github.com/dfinity/pic-js/blob/2ffce9ba1232e8156fb433a0b547e8b329137a5f/packages/pic/src/pocket-ic-types.ts#L430)

Deploys the SNS-W and aggregator canisters, sets up the SNS subnet list in the SNS-W canister according to PocketIC topology,
and uploads the SNS canister WASMs to the SNS-W canister.

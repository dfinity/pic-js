---
title: IcpFeatures
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:338](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L338)

Specifies ICP features enabled by deploying their corresponding system canisters
when creating a PocketIC instance and keeping them up to date during the PocketIC instance lifetime.
The subnets to which the corresponding system canisters are deployed must be empty.
An ICP feature is enabled if its `IcpFeaturesConfig` is provided, i.e., if the corresponding field is set.

## Properties

### cyclesMinting?

> `optional` **cyclesMinting**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:350](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L350)

Deploys the NNS cycles minting canister, sets ICP/XDR conversion rate, and keeps its subnet lists in sync with PocketIC topology.
If enabled, the default timestamp of a PocketIC instance is set to 10 May 2021 10:00:01 AM CEST
(the smallest value that is strictly larger than the default timestamp hard-coded in the CMC state).

***

### cyclesToken?

> `optional` **cyclesToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:358](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L358)

Deploys the cycles ledger and index canisters.

***

### icpToken?

> `optional` **icpToken**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:354](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L354)

Deploys the ICP ledger and index canisters and initializes the ICP account of the anonymous principal with 1,000,000,000 ICP.

***

### ii?

> `optional` **ii**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:372](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L372)

Deploys the Internet Identity canister.

***

### nnsGovernance?

> `optional` **nnsGovernance**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:363](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L363)

Deploys the NNS governance and root canisters and sets up an initial NNS neuron with 1 ICP stake.
The initial NNS neuron is controlled by the principal `hpikg-6exdt-jn33w-ndty3-fc7jc-tl2lr-buih3-cs3y7-tftkp-sfp62-gqe`.

***

### nnsUi?

> `optional` **nnsUi**: `undefined`

Defined in: [packages/pic/src/pocket-ic-types.ts:376](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L376)

Currently not supported.

***

### registry?

> `optional` **registry**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:344](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L344)

Deploys the NNS registry canister and keeps its content in sync with registry used internally by PocketIC.
Note. The registry used internally by PocketIC is not updated after changing the registry stored in the registry canister
(e.g., after executing an NNS proposal mutating the registry).

***

### sns?

> `optional` **sns**: [`DefaultConfig`](../enumerations/IcpFeaturesConfig.md#defaultconfig)

Defined in: [packages/pic/src/pocket-ic-types.ts:368](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L368)

Deploys the SNS-W and aggregator canisters, sets up the SNS subnet list in the SNS-W canister according to PocketIC topology,
and uploads the SNS canister WASMs to the SNS-W canister.

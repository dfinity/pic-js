---
title: UpdateCanisterSettingsOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:684](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L684)

Options for updating the settings of a given canister.

## See

[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Extends

- `Partial`\<[`CanisterSettings`](CanisterSettings.md)\>

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:689](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L689)

The Principal of the canister to update the settings for.

***

### computeAllocation?

> `optional` **computeAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:471](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L471)

The compute allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`computeAllocation`](CanisterSettings.md#computeallocation)

***

### controllers?

> `optional` **controllers**: `Principal`[]

Defined in: [pocket-ic-types.ts:466](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L466)

The controllers of the canister.
Defaults to the sender, which defaults to the anonymous principal.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`controllers`](CanisterSettings.md#controllers)

***

### freezingThreshold?

> `optional` **freezingThreshold**: `bigint`

Defined in: [pocket-ic-types.ts:481](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L481)

The freezing threshold of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`freezingThreshold`](CanisterSettings.md#freezingthreshold)

***

### memoryAllocation?

> `optional` **memoryAllocation**: `bigint`

Defined in: [pocket-ic-types.ts:476](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L476)

The memory allocation of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`memoryAllocation`](CanisterSettings.md#memoryallocation)

***

### reservedCyclesLimit?

> `optional` **reservedCyclesLimit**: `bigint`

Defined in: [pocket-ic-types.ts:486](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L486)

The reserved cycles limit of the canister.

#### Inherited from

[`CanisterSettings`](CanisterSettings.md).[`reservedCyclesLimit`](CanisterSettings.md#reservedcycleslimit)

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:695](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L695)

The Principal to send the request as.
Defaults to the anonymous principal.

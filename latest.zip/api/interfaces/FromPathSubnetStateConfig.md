---
title: FromPathSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:210](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L210)

Options for creating a subnet from an existing state on the filesystem.

## Properties

### path

> **path**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:232](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L232)

The path to the subnet state.

This directory should have the following structure:
```text
  |-- backups/
  |-- checkpoints/
  |-- diverged_checkpoints/
  |-- diverged_state_markers/
  |-- fs_tmp/
  |-- page_deltas/
  |-- tip/
  |-- tmp/
  |-- states_metadata.pbuf
```

***

### type

> **type**: [`FromPath`](../enumerations/SubnetStateType.md#frompath)

Defined in: [packages/pic/src/pocket-ic-types.ts:214](https://github.com/dfinity/pic-js/blob/0053d1dfa85b63fb509be8a8a93813c1049c166a/packages/pic/src/pocket-ic-types.ts#L214)

The type of subnet state to initialize the subnet with.

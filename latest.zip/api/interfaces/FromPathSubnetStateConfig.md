---
title: FromPathSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [packages/pic/src/pocket-ic-types.ts:250](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L250)

Options for creating a subnet from an existing state on the filesystem.

## Properties

### path

> **path**: `string`

Defined in: [packages/pic/src/pocket-ic-types.ts:272](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L272)

The path to the subnet state.

This directory should have the following structure:
```text
  |-- backups/
  |-- checkpoints/
  |-- diverged_checkpoints/
  |-- diverged_state_markers/
  |-- fs_tmp/
  |-- page_deltas/
  |-- tip/
  |-- tmp/
  |-- states_metadata.pbuf
```

***

### type

> **type**: [`FromPath`](../enumerations/SubnetStateType.md#frompath)

Defined in: [packages/pic/src/pocket-ic-types.ts:254](https://github.com/dfinity/pic-js/blob/1fe4b819df41e6da1ee32429637f6cc3e147dfee/packages/pic/src/pocket-ic-types.ts#L254)

The type of subnet state to initialize the subnet with.

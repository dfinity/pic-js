---
title: FromPathSubnetStateConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:206](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L206)

Options for creating a subnet from an existing state on the filesystem.

## Properties

### path

> **path**: `string`

Defined in: [pocket-ic-types.ts:228](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L228)

The path to the subnet state.

This directory should have the following structure:
```text
  |-- backups/
  |-- checkpoints/
  |-- diverged_checkpoints/
  |-- diverged_state_markers/
  |-- fs_tmp/
  |-- page_deltas/
  |-- tip/
  |-- tmp/
  |-- states_metadata.pbuf
```

***

### type

> **type**: [`FromPath`](../enumerations/SubnetStateType.md#frompath)

Defined in: [pocket-ic-types.ts:210](https://github.com/dfinity/pic-js/blob/8baa58964fe24736564351a2ae389b72e7450717/packages/pic/src/pocket-ic-types.ts#L210)

The type of subnet state to initialize the subnet with.

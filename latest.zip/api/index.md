---
title: Overview
editUrl: false
next: true
prev: true
---


- [PocketIc](classes/PocketIc.md)
- [PocketIcServer](classes/PocketIcServer.md)
- [Actor](interfaces/Actor.md)
- [createIdentity](functions/createIdentity.md)
- [generateRandomIdentity](functions/generateRandomIdentity.md)

## Other

- [CanisterHttpMethod](enumerations/CanisterHttpMethod.md)
- [SubnetStateType](enumerations/SubnetStateType.md)
- [SubnetType](enumerations/SubnetType.md)
- [CreateInstanceOptions](interfaces/CreateInstanceOptions.md)
- [DeferredActorMethod](interfaces/DeferredActorMethod.md)
- [FromPathSubnetStateConfig](interfaces/FromPathSubnetStateConfig.md)
- [HttpsOutcallRejectResponse](interfaces/HttpsOutcallRejectResponse.md)
- [HttpsOutcallSuccessResponse](interfaces/HttpsOutcallSuccessResponse.md)
- [MockPendingHttpsOutcallOptions](interfaces/MockPendingHttpsOutcallOptions.md)
- [NewSubnetStateConfig](interfaces/NewSubnetStateConfig.md)
- [PendingHttpsOutcall](interfaces/PendingHttpsOutcall.md)
- [SetupCanisterOptions](interfaces/SetupCanisterOptions.md)
- [StartServerOptions](interfaces/StartServerOptions.md)
- [SubnetConfig](interfaces/SubnetConfig.md)
- [SubnetTopology](interfaces/SubnetTopology.md)
- [ApplicationSubnetConfig](type-aliases/ApplicationSubnetConfig.md)
- [ApplicationSubnetStateConfig](type-aliases/ApplicationSubnetStateConfig.md)
- [BitcoinSubnetConfig](type-aliases/BitcoinSubnetConfig.md)
- [BitcoinSubnetStateConfig](type-aliases/BitcoinSubnetStateConfig.md)
- [CanisterHttpHeader](type-aliases/CanisterHttpHeader.md)
- [DeferredActor](type-aliases/DeferredActor.md)
- [DeferredActorInterface](type-aliases/DeferredActorInterface.md)
- [FiduciarySubnetConfig](type-aliases/FiduciarySubnetConfig.md)
- [FiduciarySubnetStateConfig](type-aliases/FiduciarySubnetStateConfig.md)
- [HttpsOutcallResponseMock](type-aliases/HttpsOutcallResponseMock.md)
- [IiSubnetConfig](type-aliases/IiSubnetConfig.md)
- [IiSubnetStateConfig](type-aliases/IiSubnetStateConfig.md)
- [NnsSubnetConfig](type-aliases/NnsSubnetConfig.md)
- [NnsSubnetStateConfig](type-aliases/NnsSubnetStateConfig.md)
- [SnsSubnetConfig](type-aliases/SnsSubnetConfig.md)
- [SnsSubnetStateConfig](type-aliases/SnsSubnetStateConfig.md)
- [SystemSubnetConfig](type-aliases/SystemSubnetConfig.md)
- [SystemSubnetStateConfig](type-aliases/SystemSubnetStateConfig.md)
- [VerifiedApplicationSubnetConfig](type-aliases/VerifiedApplicationSubnetConfig.md)
- [VerifiedApplicationSubnetStateConfig](type-aliases/VerifiedApplicationSubnetStateConfig.md)
- [createActorClass](functions/createActorClass.md)
- [createDeferredActorClass](functions/createDeferredActorClass.md)

## Types

- [ActorMethod](interfaces/ActorMethod.md)
- [CanisterFixture](interfaces/CanisterFixture.md)
- [CanisterSettings](interfaces/CanisterSettings.md)
- [CreateCanisterOptions](interfaces/CreateCanisterOptions.md)
- [InstallCodeOptions](interfaces/InstallCodeOptions.md)
- [QueryCallOptions](interfaces/QueryCallOptions.md)
- [ReinstallCodeOptions](interfaces/ReinstallCodeOptions.md)
- [StartCanisterOptions](interfaces/StartCanisterOptions.md)
- [StopCanisterOptions](interfaces/StopCanisterOptions.md)
- [UpdateCallOptions](interfaces/UpdateCallOptions.md)
- [UpdateCanisterSettingsOptions](interfaces/UpdateCanisterSettingsOptions.md)
- [UpgradeCanisterOptions](interfaces/UpgradeCanisterOptions.md)
- [ActorInterface](type-aliases/ActorInterface.md)

---
title: HttpsOutcallSuccessResponse
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:777](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L777)


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:796](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L796)

The body of the response.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:791](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L791)

The headers of the response.

***

### statusCode

> **statusCode**: `number`

Defined in: [pocket-ic-types.ts:786](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L786)

The status code of the response.

***

### type

> **type**: `"success"`

Defined in: [pocket-ic-types.ts:781](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L781)

The type of the response, either `'success'` or `'response'`.

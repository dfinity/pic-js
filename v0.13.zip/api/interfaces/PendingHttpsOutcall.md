---
title: PendingHttpsOutcall
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:678](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L678)

A pending HTTPS outcall.


### body

> **body**: `Uint8Array`

Defined in: [pocket-ic-types.ts:708](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L708)

The body of the pending request.

***

### headers

> **headers**: [`CanisterHttpHeader`](../type-aliases/CanisterHttpHeader.md)[]

Defined in: [pocket-ic-types.ts:703](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L703)

The headers of the pending request.

***

### httpMethod

> **httpMethod**: [`CanisterHttpMethod`](../enumerations/CanisterHttpMethod.md)

Defined in: [pocket-ic-types.ts:693](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L693)

The HTTP method used for this request.

***

### maxResponseBytes?

> `optional` **maxResponseBytes**: `number`

Defined in: [pocket-ic-types.ts:714](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L714)

The maximum number of bytes expected in the response body that was set
by the canister making the request.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:688](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L688)

The HTTPS Outcall request Id. Use this Id when setting a mock response
for this request.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:682](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L682)

The subnet ID to that the HTTPS Outcall is being sent from.

***

### url

> **url**: `string`

Defined in: [pocket-ic-types.ts:698](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L698)

The target URL of the pending request.

---
title: CanisterFixture
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:346](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L346)

A canister testing fixture for PocketIC that provides essential testing primitives
such as an [Actor](Actor.md) and CanisterId.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Type Parameters

### T

`T` *extends* [`ActorInterface`](../type-aliases/ActorInterface.md)\<`T`\> = [`ActorInterface`](../type-aliases/ActorInterface.md)

## Properties

### actor

> **actor**: [`Actor`](Actor.md)\<`T`\>

Defined in: [pocket-ic-types.ts:350](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L350)

The [Actor](Actor.md) instance.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:355](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L355)

The Principal of the canister.

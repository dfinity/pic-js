---
title: StartCanisterOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:433](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L433)

Options for starting a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:437](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L437)

The Principal of the canister to start.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:443](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L443)

The Principal to send the request as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:448](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L448)

The ID of the subnet that the canister resides on.

---
title: MockPendingHttpsOutcallOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:745](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L745)

Options for mocking a response to a pending HTTPS outcall.


### additionalResponses?

> `optional` **additionalResponses**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)[]

Defined in: [pocket-ic-types.ts:767](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L767)

Additional responses to mock for the pending HTTPS outcall.

If non-empty, the total number of responses (one plus the number of additional responses)
must be equal to the size of the subnet on which the canister making the HTTP outcall is deployed.

***

### requestId

> **requestId**: `number`

Defined in: [pocket-ic-types.ts:754](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L754)

The HTTPS Outcall request Id to mock a response for.

***

### response

> **response**: [`HttpsOutcallResponseMock`](../type-aliases/HttpsOutcallResponseMock.md)

Defined in: [pocket-ic-types.ts:759](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L759)

The response to mock for the pending HTTPS outcall.

***

### subnetId

> **subnetId**: `Principal`

Defined in: [pocket-ic-types.ts:749](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L749)

The subnet ID to that the HTTPS Outcall is being sent from.

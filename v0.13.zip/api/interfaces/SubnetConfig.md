---
title: SubnetConfig
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:77](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L77)

Common options for creating a subnet.


### T

`T` *extends* [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md) = [`NewSubnetStateConfig`](NewSubnetStateConfig.md) \| [`FromPathSubnetStateConfig`](FromPathSubnetStateConfig.md)

## Properties

### enableBenchmarkingInstructionLimits?

> `optional` **enableBenchmarkingInstructionLimits**: `boolean`

Defined in: [pocket-ic-types.ts:92](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L92)

Whether to enable benchmarking instruction limits.
Defaults to `false`.

***

### enableDeterministicTimeSlicing?

> `optional` **enableDeterministicTimeSlicing**: `boolean`

Defined in: [pocket-ic-types.ts:86](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L86)

Whether to enable deterministic time slicing.
Defaults to `true`.

***

### state

> **state**: `T`

Defined in: [pocket-ic-types.ts:97](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L97)

The state configuration for the subnet.

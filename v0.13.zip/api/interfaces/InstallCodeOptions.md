---
title: InstallCodeOptions
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:481](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L481)

Options for installing a WASM module to a given canister.


[Principal](https://js.icp.build/core/latest/libs/principal/api/classes/principal/)

## Properties

### arg?

> `optional` **arg**: `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:498](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L498)

Candid encoded argument to pass to the canister's init function.
Defaults to an empty ArrayBuffer.

***

### canisterId

> **canisterId**: `Principal`

Defined in: [pocket-ic-types.ts:485](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L485)

The Principal of the canister to install the code to.

***

### sender?

> `optional` **sender**: `Principal`

Defined in: [pocket-ic-types.ts:504](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L504)

The principal to install the code as.
Defaults to the anonymous principal.

***

### targetSubnetId?

> `optional` **targetSubnetId**: `Principal`

Defined in: [pocket-ic-types.ts:509](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L509)

The ID of the subnet that the canister resides on.

***

### wasm

> **wasm**: `string` \| `ArrayBufferLike`

Defined in: [pocket-ic-types.ts:492](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L492)

The WASM module to install to the canister.
If a string is passed, it is treated as a path to a file.
If an `ArrayBufferLike` is passed, it is treated as the WASM module itself.

---
title: FiduciarySubnetConfig
editUrl: false
next: true
prev: true
---

> **FiduciarySubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`FiduciarySubnetStateConfig`](FiduciarySubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:135](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L135)

Options for creating a Fiduciary subnet.

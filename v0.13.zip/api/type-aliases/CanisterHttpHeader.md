---
title: CanisterHttpHeader
editUrl: false
next: true
prev: true
---

> **CanisterHttpHeader** = \[`string`, `string`\]

Defined in: [pocket-ic-types.ts:740](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L740)

An HTTP header for an HTTPS outcall.

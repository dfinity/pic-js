---
title: VerifiedApplicationSubnetStateConfig
editUrl: false
next: true
prev: true
---

> **VerifiedApplicationSubnetStateConfig** = [`NewSubnetStateConfig`](../interfaces/NewSubnetStateConfig.md)

Defined in: [pocket-ic-types.ts:182](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L182)

Options for a verified application subnet's state.

---
title: BitcoinSubnetConfig
editUrl: false
next: true
prev: true
---

> **BitcoinSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`BitcoinSubnetStateConfig`](BitcoinSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:145](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L145)

Options for creating a Bitcoin subnet.

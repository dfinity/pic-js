---
title: SystemSubnetConfig
editUrl: false
next: true
prev: true
---

> **SystemSubnetConfig** = [`SubnetConfig`](../interfaces/SubnetConfig.md)\<[`SystemSubnetStateConfig`](SystemSubnetStateConfig.md)\>

Defined in: [pocket-ic-types.ts:155](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L155)

Options for creating a system subnet.

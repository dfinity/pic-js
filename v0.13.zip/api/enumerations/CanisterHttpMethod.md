---
title: CanisterHttpMethod
editUrl: false
next: true
prev: true
---

Defined in: [pocket-ic-types.ts:720](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L720)

The HTTP method used for an HTTPS outcall.


### GET

> **GET**: `"GET"`

Defined in: [pocket-ic-types.ts:724](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L724)

A GET request.

***

### HEAD

> **HEAD**: `"HEAD"`

Defined in: [pocket-ic-types.ts:734](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L734)

A HEAD request.

***

### POST

> **POST**: `"POST"`

Defined in: [pocket-ic-types.ts:729](https://github.com/dfinity/pic-js/blob/9bbc810c12b597cf8ce39320447324d9e18f661e/packages/pic/src/pocket-ic-types.ts#L729)

A POST request.
